package models;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.JComboBox;

public class StaffWindowManagement {
	
	
	int customerId;
	int bookingId;
	int roomId;
	static int roomTypeId;
	int roomStatusId;
	String roomType;
	String bookingStatus;
	Date arrivalDate,departureDate;
	int roomNumber;
	String customerName;
	String roomStatus;
	String fullName;
	int staffId;
	int total;
	int rate;
	int quantity;
	String serviceName;
	int extServiceId;
	String staffName;
	int rbServiceId;
	int billingId;
	Date billingDate;
	String address;
	String email;
	int roomRate;
	int sQuantity;
	int sCharge;
	int sTotal;
	String iName;
	int iPrice;
	int roomPrice;
	int grandTotal;
	int iQty;
	int iTotal;
	public StaffWindowManagement() {
		
	}
	
	public StaffWindowManagement(int customerId, int bookingId, int roomId, int roomTypeId, int roomStatusId) {
		
		this.customerId = customerId;
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.roomTypeId = roomTypeId;
		this.roomStatusId = roomStatusId;
	}

	public StaffWindowManagement(int customerId, int bookingId, int roomNumber) {
		this.customerId = customerId;
		this.bookingId = bookingId;
		this.roomNumber = roomNumber;
		
	}
	
	public StaffWindowManagement(int customerId, int bookingId) {
		this.customerId = customerId;
		this.bookingId = bookingId;
	}
	public StaffWindowManagement(Date departureDate,int roomNumber) {
		this.departureDate=departureDate;
		this.roomNumber=roomNumber;
	}
	
	public int getIQty() {
		return iQty;
	}

	public void setIQty(int iQty) {
		this.iQty = iQty;
	}

	public int getITotal() {
		return iTotal;
	}

	public void setITotal(int iTotal) {
		this.iTotal = iTotal;
	}

	public Date getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(Date billingDate) {
		this.billingDate = billingDate;
	}

	public int getRbServiceId() {
		return rbServiceId;
	}

	public void setRbServiceId(int rbServiceId) {
		this.rbServiceId = rbServiceId;
	}

	public int getBillingId() {
		return billingId;
	}

	public void setBillingId(int billingId) {
		this.billingId = billingId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getRoomRate() {
		return roomRate;
	}

	public void setRoomRate(int roomRate) {
		this.roomRate = roomRate;
	}

	public int getSQuantity() {
		return sQuantity;
	}

	public void setSQuantity(int sQuantity) {
		this.sQuantity = sQuantity;
	}

	public int getSCharge() {
		return sCharge;
	}

	public void setSCharge(int sCharge) {
		this.sCharge = sCharge;
	}

	public int getSTotal() {
		return sTotal;
	}

	public void setSTotal(int sTotal) {
		this.sTotal = sTotal;
	}

	public String getIName() {
		return iName;
	}

	public void setIName(String iName) {
		this.iName = iName;
	}

	public int getIPrice() {
		return iPrice;
	}

	public void setIPrice(int iPrice) {
		this.iPrice = iPrice;
	}

	public int getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(int roomPrice) {
		this.roomPrice = roomPrice;
	}

	public int getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(int grandTotal) {
		this.grandTotal = grandTotal;
	}

	public int getRBServiceId() {
		return rbServiceId;
	}

	public void setRBServiceId(int rbServiceId) {
		this.rbServiceId = rbServiceId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getExtServiceId() {
		return extServiceId;
	}

	public void setExtServiceId(int extServiceId) {
		this.extServiceId = extServiceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}
	
	public int getStaffId() {
		return staffId;
	}

	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public String getRoomStatus() {
		return roomStatus;
	}

	public void setRoomStatus(String roomStatus) {
		this.roomStatus = roomStatus;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	

	public static int getRoomTypeId() {
		return roomTypeId;
	}

	public static void setRoomTypeId(int roomTypeId) {
		StaffWindowManagement.roomTypeId = roomTypeId;
	}

	public int getRoomStatusId() {
		return roomStatusId;
	}

	public void setRoomStatusId(int roomStatusId) {
		this.roomStatusId = roomStatusId;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	
}
