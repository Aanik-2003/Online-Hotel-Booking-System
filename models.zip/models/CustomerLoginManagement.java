package models;

public class CustomerLoginManagement {
	
	public static int customerTypeId;
	public static int customerId;
	String firstName;
	String email;
	String password;
	boolean isUser;
	
	public CustomerLoginManagement() {
		
	}
	
	public CustomerLoginManagement(int customerTypeId, int customerId, String firstName,String email, String password, boolean isUser) {
		
		CustomerLoginManagement.customerTypeId = customerTypeId;
		CustomerLoginManagement.customerId = customerId;
		this.firstName = firstName;
		this.email = email;
		this.password = password;
		this.isUser = isUser;
	}
	
	public static int getCustomerTypeId() {
		return customerTypeId;
	}

	public static void setCustomerTypeId(int customerTypeId) {
		CustomerLoginManagement.customerTypeId = customerTypeId;
	}

	public static int getCustomerId() {
		return customerId;
	}

	public static void setCustomerId(int customerId) {
		CustomerLoginManagement.customerId = customerId;
	}
	
	public  String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isUser() {
		return isUser;
	}

	public void setUser(boolean isUser) {
		this.isUser = isUser;
	}
	
}