package views;

import java.awt.*;	// importing all the packages from action window toolkit
import java.awt.event.*;	// importing all the packages from 
import javax.swing.*;	// importing all the packages from swing

public class MainWindow extends JFrame implements ActionListener{
	
//	instance variables
	JMenuBar menuBar;
	JMenu staffMenu, guestMenu, exitMenu;
	JMenuItem staffLogin, guestRegister, guestLogin, close;
	ImageIcon i;
	JLabel image,txt1,txt2,txt3,txt4;
	JButton bookBtn;
		
	public MainWindow() {

		setTitle("Main Window"); // title of window
		setResizable(true);	// can change the size of window
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();  // create an object 
	    setSize(screenSize.width, screenSize.height); // Set the size of the frame to be the size of the screen
		
		setLayout(null);  // manual set of layout
		
		i= new ImageIcon("C:\\Users\\user\\OneDrive\\Pictures\\main1.jpg");  // creates an object and adding image
		image= new JLabel(i);
		image.setBounds(0,0,screenSize.width,screenSize.height);	// setting size and location of image
		
		txt1 = new JLabel("WELCOME TO LUTON HOTEL!");	// adding new text
		txt1.setBounds(350,5,1000,100);		// setting size and location of text1
		txt1.setForeground(Color.BLACK);	// setting foreground color of text1 
		txt1.setFont(new Font("serif",Font.BOLD, 60));	// setting font of text1
		
		
		txt2 = new JLabel("Discover The Perfect Balance Of Hospitality, Luxury and Comfort.");	// adding new text
		txt2.setBounds(300,140,1200,100);	// setting size and location of text2
		txt2.setForeground(Color.BLACK);	// setting foreground color of text2
		txt2.setFont(new Font("serif",Font.BOLD, 40));	// setting font of text2
		
		
		txt3 = new JLabel("We are focused on providing clients with the highest level of comfort "	// adding new text
				+ "and excellent affordable rates.");
		txt3.setBounds(400,200,1000,100);	// setting size and location of text3
		txt3.setForeground(Color.BLACK);	// setting foreground color of text3
		txt3.setFont(new Font("ITALIC",Font.ITALIC, 20));	// setting font of text3
		
		
		txt4 = new JLabel("Enjoy Your Stay At Our Hotel \u263A");	// adding new text
		txt4.setBounds(30,600,1200,100);	// setting size and location of text4
		txt4.setForeground(Color.ORANGE);		// setting foreground color of text4
		txt4.setFont(new Font("serif",Font.BOLD, 30));	// setting font size of text4
		
		
		bookBtn = new JButton("BOOK NOW");	// adding new button
		bookBtn.setBounds(100,680,122,50);	// setting size  and location of 'book' button
		bookBtn.setForeground(Color.BLACK);	// setting foreground color 
		bookBtn.setBackground(Color.ORANGE);	// setting background color
		bookBtn.setFont(new Font("serif", Font.BOLD, 15)); // setting font
		bookBtn.addActionListener(this);	// adding action listener to 'book' button
		
		
		menuBar = new JMenuBar();	// 
		menuBar.setBackground(Color.black);	// setting background color
		
		
		staffMenu = new JMenu("Staff");	
		staffMenu.setForeground(Color.white);
		
		
		guestMenu = new JMenu("Guest");
		guestMenu.setForeground(Color.white);
		
		
		exitMenu = new JMenu("Exit");
		exitMenu.setForeground(Color.white);
		
		staffLogin = new JMenuItem("Login");
		staffLogin.addActionListener(this);   
		guestRegister = new JMenuItem("Register");
		guestRegister.addActionListener(this);
		guestLogin = new JMenuItem("Login");
		guestLogin.addActionListener(this);
		close = new JMenuItem("Close");
		close.addActionListener(this);
		
		
		staffMenu.add(staffLogin);
		guestMenu.add(guestRegister);
		guestMenu.add(guestLogin);
		exitMenu.add(close);

		menuBar.add(staffMenu);
	    menuBar.add(guestMenu);
	    menuBar.add(exitMenu);
		
		image.add(txt1);
		image.add(txt2);
		image.add(txt3);
		image.add(txt4);
		image.add(bookBtn);
		
		setJMenuBar(menuBar);
		add(image);
		setVisible(true);
		
		txt1.setVisible(false);
	    txt4.setVisible(false);
	    try {
	        Thread.sleep(500);
	    }
	    catch(Exception e) {
	        e.printStackTrace();
	    }
	    txt1.setVisible(true);
	    txt4.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==staffLogin) {
			
			StaffLoginWindow sLoginWindow = new StaffLoginWindow();
			sLoginWindow.setVisible(true);
			
		}
		else if(ae.getSource()==guestRegister) {
			this.dispose();
			RegisterWindow rWindow = new RegisterWindow();
			rWindow.setVisible(true);
		}
		else if(ae.getSource()==guestLogin) {
			GuestLoginWindow gLoginWindow = new GuestLoginWindow();
			gLoginWindow.setVisible(true);
		}
		else if(ae.getSource()==bookBtn) {
			GuestLoginWindow lWindow = new GuestLoginWindow();
			lWindow.setVisible(true);
		}		
		else if(ae.getSource()==close) {
			this.dispose();
		}
	}
	public static void main(String[] args) {
		new MainWindow();
	}
}
