package views;

import javax.swing.*;

import controllers.StaffLoginController;
import models.StaffLoginManagement;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StaffLoginWindow extends JFrame implements ActionListener{
	
	JLabel customerTypeLbl, userLbl, passLbl;
	JTextField userFld, passFld;
	JButton loginBtn, closeBtn;
	JCheckBox passwordCheck;
	
	/**
	 * 
	 */
	public StaffLoginWindow() {
		
		setTitle("Login Window");
		setSize(350,250);
		setResizable(false);
		setLocation(640,360);
		setUndecorated(true); // remove window decorations
	    getRootPane().setOpaque(false); // make the content pane transparent
	    setBackground(new Color(10, 10, 10, 100)); // make the background transparent
	    setLayout(null);
	    
	    
		userLbl = new JLabel("Username/Email:");
		userLbl.setBounds(70,30,100,20);
        userLbl.setBackground(Color.WHITE);
        
		userFld = new JTextField();
		userFld.setBounds(70,55,200,20);
		
		passLbl = new JLabel("Password:");
		passLbl.setBounds(70,85,100,20);
		passLbl.setBackground(Color.WHITE);

		passFld = new JPasswordField();
		passFld.setBounds(70,110,200,20);
		
		passwordCheck = new JCheckBox("Show Password");
		passwordCheck.setBounds(110,140,110,20);
		passwordCheck.setFont(new Font("serif",Font.BOLD, 12));
		passwordCheck.setBackground(Color.WHITE);
		passwordCheck.addItemListener(new ItemListener() {
		    public void itemStateChanged(ItemEvent e) {
		        if (e.getStateChange() == ItemEvent.SELECTED) {
		            ((JPasswordField) passFld).setEchoChar((char)0); // show password
		        } else {
		            ((JPasswordField) passFld).setEchoChar('\u2022'); // hide password with bullet character
		        }
		    }
		});

		loginBtn= new JButton("Login");
		loginBtn.setBounds(70,190,80,20);
		loginBtn.setFont(new Font("serif",Font.BOLD, 12));
		loginBtn.addActionListener(this);
		
		closeBtn = new JButton("Close");
		closeBtn.setBounds(170,190,80,20);
		closeBtn.setFont(new Font("serif",Font.BOLD, 12));
		closeBtn.addActionListener(this);
		
		
		add(userLbl);
		add(userFld);
		add(passLbl);
		add(passFld);
		add(loginBtn);
		add(closeBtn);
		add(passwordCheck);
		
		setOpacity(0.9f);
		setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ae) {
		
	    if (ae.getSource() == loginBtn) {
	    	
	    	StaffLoginManagement staffLogin = new StaffLoginManagement();
			StaffLoginController slc = new StaffLoginController();
			
			staffLogin.setEmail(userFld.getText());
			staffLogin.setPassword(passFld.getText());
			slc.setUser(staffLogin);
			slc.staffLogin();
			staffLogin = slc.getUser();
			
			if(staffLogin.getStaffId()>=1) {
			
			JOptionPane.showMessageDialog(this, "Login Successful");
			
			StaffWindow sWindow = new StaffWindow();
			sWindow.setVisible(true);
			this.setVisible(false);
			}
			else {
				JOptionPane.showMessageDialog(this, "Invalid username or password");
			}
    	}
	
	    else if(ae.getSource()==closeBtn) {
	    	setVisible(false);
	    }
	}
	public static void main(String[] args) {
		new StaffLoginWindow();
	}
	
}	
