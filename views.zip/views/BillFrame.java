package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controllers.StaffWindowController;
import controllers.StaffWindowJDBC;
import models.StaffWindowManagement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;

import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.print.PrintException;
import javax.swing.JButton;
import java.awt.Color;

public class BillFrame extends JFrame {

	private JPanel contentPane;
	private final JSeparator separator = new JSeparator();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private final JSeparator separator_1 = new JSeparator();
	private final JSeparator separator_2 = new JSeparator();
	private final JSeparator separator_3 = new JSeparator();
	private final JSeparator separator_4 = new JSeparator();
	private final JSeparator separator_6 = new JSeparator();
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JButton closeBtn;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BillFrame frame = new BillFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public BillFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 599, 623);
		setLocation(500,50);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("INVOICE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(13, 22, 141, 32);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("HOTEL LUTON\r\n");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBounds(380, 14, 207, 52);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("INVOICE No :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBounds(36, 118, 76, 26);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("DATE :");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_1.setBounds(36, 154, 76, 26);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("PAYMENT METHOD :");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_2.setBounds(36, 190, 115, 26);
		contentPane.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("BILL TO :");
		lblNewLabel_2_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_3.setBounds(333, 118, 76, 26);
		contentPane.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("ADDRESS : ");
		lblNewLabel_2_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_4.setBounds(333, 154, 76, 26);
		contentPane.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_2_5 = new JLabel("E-MAIL :");
		lblNewLabel_2_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_5.setBounds(333, 190, 76, 26);
		contentPane.add(lblNewLabel_2_5);
		separator.setBounds(0, 244, 595, 26);
		contentPane.add(separator);
		
		JLabel lblNewLabel_2_6 = new JLabel("ROOM NO :");
		lblNewLabel_2_6.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6.setBounds(36, 274, 76, 26);
		contentPane.add(lblNewLabel_2_6);
		
		JLabel lblNewLabel_2_7 = new JLabel("ROOM TYPE :");
		lblNewLabel_2_7.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_7.setBounds(333, 280, 76, 26);
		contentPane.add(lblNewLabel_2_7);
		
		JLabel lblNewLabel_2_6_1 = new JLabel("CHECK-IN DATE :");
		lblNewLabel_2_6_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_1.setBounds(36, 310, 91, 26);
		contentPane.add(lblNewLabel_2_6_1);
		
		JLabel lblNewLabel_2_6_2 = new JLabel("CHECK-OUT DATE :");
		lblNewLabel_2_6_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_2.setBounds(333, 310, 105, 26);
		contentPane.add(lblNewLabel_2_6_2);
		
		JLabel lblNewLabel_2_6_3 = new JLabel("PRICE/NIGHT :");
		lblNewLabel_2_6_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3.setBounds(36, 346, 91, 26);
		contentPane.add(lblNewLabel_2_6_3);
		
		JLabel lblNewLabel_2_6_4 = new JLabel("ROOM PRICE :");
		lblNewLabel_2_6_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_4.setBounds(333, 346, 76, 26);
		contentPane.add(lblNewLabel_2_6_4);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(163, 122, 115, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		textField_1.setBounds(163, 158, 115, 19);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(163, 194, 115, 19);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setEditable(false);
		textField_3.setColumns(10);
		textField_3.setBounds(411, 122, 115, 19);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setEditable(false);
		textField_4.setColumns(10);
		textField_4.setBounds(411, 158, 115, 19);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setEditable(false);
		textField_5.setColumns(10);
		textField_5.setBounds(411, 194, 115, 19);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setEditable(false);
		textField_6.setColumns(10);
		textField_6.setBounds(144, 280, 115, 19);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setEditable(false);
		textField_7.setColumns(10);
		textField_7.setBounds(144, 314, 115, 19);
		contentPane.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setEditable(false);
		textField_8.setColumns(10);
		textField_8.setBounds(144, 350, 115, 19);
		contentPane.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setEditable(false);
		textField_9.setColumns(10);
		textField_9.setBounds(446, 280, 115, 19);
		contentPane.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setEditable(false);
		textField_10.setColumns(10);
		textField_10.setBounds(446, 314, 115, 19);
		contentPane.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setEditable(false);
		textField_11.setColumns(10);
		textField_11.setBounds(446, 350, 115, 19);
		contentPane.add(textField_11);
		
		JLabel lblNewLabel_2_6_3_1 = new JLabel("Description");
		lblNewLabel_2_6_3_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_1.setBounds(36, 403, 91, 26);
		contentPane.add(lblNewLabel_2_6_3_1);
		
		JLabel lblNewLabel_2_6_3_2 = new JLabel("Name");
		lblNewLabel_2_6_3_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_2.setBounds(168, 403, 91, 26);
		contentPane.add(lblNewLabel_2_6_3_2);
		
		JLabel lblNewLabel_2_6_3_3 = new JLabel("Quantity");
		lblNewLabel_2_6_3_3.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_3.setBounds(269, 403, 91, 26);
		contentPane.add(lblNewLabel_2_6_3_3);
		
		JLabel lblNewLabel_2_6_3_4 = new JLabel("Rate(£)");
		lblNewLabel_2_6_3_4.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_4.setBounds(380, 403, 91, 26);
		contentPane.add(lblNewLabel_2_6_3_4);
		
		JLabel lblNewLabel_2_6_3_5 = new JLabel("Total");
		lblNewLabel_2_6_3_5.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_5.setBounds(508, 403, 77, 26);
		contentPane.add(lblNewLabel_2_6_3_5);
		separator_1.setBounds(-14, 403, 599, 36);
		contentPane.add(separator_1);
		separator_2.setBounds(0, 434, 599, 36);
		contentPane.add(separator_2);
		separator_3.setBounds(0, 466, 585, 36);
		contentPane.add(separator_3);
		separator_4.setBounds(0, 501, 595, 36);
		contentPane.add(separator_4);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(486, 547, 76, -22);
		contentPane.add(separator_5);
		separator_6.setBounds(380, 540, 215, 36);
		contentPane.add(separator_6);
		
		JLabel lblNewLabel_2_6_3_1_1 = new JLabel("TOTAL");
		lblNewLabel_2_6_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_6_3_1_1.setBounds(392, 512, 69, 19);
		contentPane.add(lblNewLabel_2_6_3_1_1);
		
		textField_14 = new JTextField();
		textField_14.setEditable(false);
		textField_14.setColumns(10);
		textField_14.setBounds(258, 434, 76, 32);
		contentPane.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setEditable(false);
		textField_15.setColumns(10);
		textField_15.setBounds(362, 434, 76, 32);
		contentPane.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setEditable(false);
		textField_16.setColumns(10);
		textField_16.setBounds(480, 434, 105, 32);
		contentPane.add(textField_16);
		
		textField_12 = new JTextField();
		textField_12.setEditable(false);
		textField_12.setColumns(10);
		textField_12.setBounds(13, 434, 99, 32);
		contentPane.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setEditable(false);
		textField_13.setColumns(10);
		textField_13.setBounds(137, 434, 99, 32);
		contentPane.add(textField_13);
		
		textField_17 = new JTextField();
		textField_17.setEditable(false);
		textField_17.setColumns(10);
		textField_17.setBounds(13, 466, 99, 36);
		contentPane.add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setEditable(false);
		textField_18.setColumns(10);
		textField_18.setBounds(137, 466, 99, 36);
		contentPane.add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setEditable(false);
		textField_19.setColumns(10);
		textField_19.setBounds(258, 466, 76, 36);
		contentPane.add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setEditable(false);
		textField_20.setColumns(10);
		textField_20.setBounds(362, 466, 76, 36);
		contentPane.add(textField_20);
		
		textField_21 = new JTextField();
		textField_21.setEditable(false);
		textField_21.setColumns(10);
		textField_21.setBounds(480, 466, 105, 36);
		contentPane.add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setEditable(false);
		textField_22.setColumns(10);
		textField_22.setBounds(480, 501, 105, 41);
		contentPane.add(textField_22);
		
//		StaffWindowManagement swm = new StaffWindowManagement();
		// Call the getBill() method on the instance of the StaffWindowJDBC class
		ArrayList<StaffWindowManagement> customers = new StaffWindowJDBC().getBill();
		// check if any data was retrieved
		if (!customers.isEmpty()) {

		    // retrieve the first item from the ArrayList
		    StaffWindowManagement customer = customers.get(0);

		    // set the values in the fields
		    textField.setText(Integer.toString(customer.getBillingId()));
		    textField_1.setText(String.valueOf(customer.getBillingDate()));
		    textField_2.setText("Credit Card");
		    textField_3.setText(customer.getFullName());
		    textField_4.setText(customer.getAddress());
		    textField_5.setText(customer.getEmail());
		    textField_6.setText(Integer.toString(customer.getRoomNumber()));
		    textField_9.setText(customer.getRoomType());
		    textField_7.setText(customer.getArrivalDate().toString());
		    textField_10.setText(customer.getDepartureDate().toString());
		    textField_8.setText(Integer.toString(customer.getRoomRate()));
		    textField_13.setText(customer.getServiceName());
		    textField_14.setText(Integer.toString(customer.getSQuantity()));
		    textField_15.setText(Integer.toString(customer.getSCharge()));
		    textField_16.setText(Integer.toString(customer.getSTotal()));
		    textField_18.setText(customer.getIName());
		    textField_19.setText(Integer.toString(customer.getIQty()));
		    textField_20.setText(Integer.toString(customer.getIPrice()));
		    textField_11.setText(Integer.toString(customer.getRoomPrice()));
		    textField_22.setText(Integer.toString(customer.getGrandTotal()));
		    textField_12.setText("Service Name");
		    textField_17.setText("Restaurant & Bar");

		}else {
			JOptionPane.showMessageDialog(this, "Error!");
		}

		
		
		JButton printBtn = new JButton("PRINT");
		printBtn.setFont(new Font("Tahoma", Font.BOLD, 8));
		printBtn.setBounds(0, 567, 61, 21);
		contentPane.add(printBtn);
		
		closeBtn = new JButton("CLOSE");
		closeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		closeBtn.setForeground(new Color(255, 0, 0));
		closeBtn.setBackground(new Color(240, 240, 240));
		closeBtn.setBounds(69, 566, 85, 21);
		
		contentPane.add(closeBtn);
		
		printBtn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					PrinterJob pj = PrinterJob.getPrinterJob();
					pj.setPrintable(new Printable(){
						public int print(Graphics graphics, PageFormat pf, int pageIndex)
							throws PrinterException{
							if (pageIndex>0) {
								return NO_SUCH_PAGE;
							}
							Graphics2D g2 = (Graphics2D) graphics;
							g2.translate(pf.getImageableX(), pf.getImageableY());
							BillFrame bf = new BillFrame();
							bf.printAll(graphics);
							return PAGE_EXISTS;
							
						}
					});
					boolean result = pj.printDialog();
					if(result) {
						pj.print();
					}
				}catch(PrinterException ex) {
					ex.printStackTrace();
					
				}
			}
		});
		
	}

	private ArrayList<StaffWindowManagement> getBill(StaffWindowManagement swm) {
		// TODO Auto-generated method stub
		return null;
	}
}
