package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import controllers.GuestWindowController;
import controllers.GuestWindowJDBC;
import controllers.RegisterController;
import models.GuestWindowManagement;
import models.CustomerLoginManagement;
import models.RegisterManagement;

public class GuestWindow extends JFrame implements ActionListener {
    
    private JDesktopPane desktopPane;  // added desktop pane
    private JMenuBar menuBar;
    private JMenu bookMenu, payMenu, exitMenu;
    private JMenuItem create, view, online, close;
    private ImageIcon i;
    private JLabel imageLbl;
    private JInternalFrame createBookFrame, viewBookFrame, onlineFrame;
    DefaultTableModel customerModel,viewModel;
    JTable bookingTable;
    JScrollPane scrollPane;
    
    public GuestWindow(CustomerLoginManagement login) {
        
    	
        desktopPane = new JDesktopPane();  // create the desktop pane
        setContentPane(desktopPane);  // set the desktop pane as the content pane
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setResizable(true);
        setTitle("Welcome : "+login.getFirstName());
        
        i = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\icons\\Lobby - Reception Area.jpg");
        imageLbl = new JLabel(i);
        imageLbl.setBounds(0, 0, screenSize.width, screenSize.height);
        desktopPane.add(imageLbl);  // add the label to the desktop pane
        
        menuBar = new JMenuBar();
        menuBar.setBackground(Color.black);
        
        bookMenu = new JMenu("Book");
        bookMenu.setForeground(Color.white);
        
        payMenu = new JMenu("Pay");
        payMenu.setForeground(Color.white);
        
        exitMenu = new JMenu("Exit");
        exitMenu.setForeground(Color.white);
        
        create = new JMenuItem("Create");
        create.addActionListener(this);
        
        view = new JMenuItem("View");
        view.addActionListener(this);
        
        online = new JMenuItem("Online");
        online.addActionListener(this);
       
        close = new JMenuItem("Close");
        close.addActionListener(this);
        
        bookMenu.add(create);
        bookMenu.add(view);
        payMenu.add(online);
        exitMenu.add(close);
        
        menuBar.add(bookMenu);
        menuBar.add(payMenu);
        menuBar.add(exitMenu);
        setJMenuBar(menuBar);
       
        createBookFrame = new JInternalFrame("Booking Form",false,true,false,false);
        initFrame1(createBookFrame);
        
        viewBookFrame = new JInternalFrame("Booking Form",false,true,false,false);
        initFrame2(viewBookFrame);
        
        onlineFrame = new JInternalFrame("Online Payment Form",false,true,false,false);
        initFrame3(onlineFrame);
        
        setVisible(true);
    }
 
    private void initFrame1 (JInternalFrame iframe) {
    	
    	JPanel panel;
    	JLabel titleLbl,arrivalDateLbl, departureDateLbl,rTypeLbl,numGuestLbl,rPriceLbl,currencyLbl,creditNumLbl,cardExpDateLbl,cvvLbl;
    	JTextField numGuestFld,rPriceFld,creditNumFld,cvvFld;
    	JDateChooser arrDate,depDate,expDate;
    	JComboBox <String>rTypeComboBox;
    	JButton submitBtn,closeBtn;
    	Calendar arrCalendar,depCalendar,expCalendar;
    	
    	
    	createBookFrame.setSize(700,500);
    	createBookFrame.setLocation(400,200);
    	createBookFrame.setResizable(false);
    	createBookFrame.setLayout(null);
    	createBookFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	createBookFrame.setTitle("Booking Form");
	    
	    titleLbl = new JLabel("Booking Form");
	    titleLbl.setBounds(250,0,200,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.black);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(50, 50, 600, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,10,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,10,150,25);
	    arrCalendar = Calendar.getInstance();
	    arrCalendar.setTime(new Date()); // set minimum selectable date to current date
        arrDate.setMinSelectableDate(arrCalendar.getTime());
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(320,10,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();
	    depDate.setBounds(440,10,150,25);
	    depCalendar = Calendar.getInstance();
        depCalendar.setTime(new Date()); // set minimum selectable date to current date
        depDate.setMinSelectableDate(depCalendar.getTime());
		
	    rTypeLbl = new JLabel("Room Type");
	    rTypeLbl.setBounds(10,60,100,20);
	    rTypeLbl.setForeground(Color.black);
	    rTypeLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    
	    String rType[] = {"Single", "Double", "Twin"};
	    rTypeComboBox = new JComboBox <>(rType);
	    rTypeComboBox.setSelectedIndex(-1);
	    rTypeComboBox.setBounds(120, 60, 150, 25);
	   	    
	    numGuestLbl = new JLabel("No. of Guest");
	    numGuestLbl.setBounds(320,60,150,20);
	    numGuestLbl.setForeground(Color.black);
	    numGuestLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    numGuestFld = new JTextField();
	    numGuestFld.setBounds(440,60,150,25);
	    numGuestFld.setEditable(false);
	    
	    rPriceLbl = new JLabel("Price/Day");
	    rPriceLbl.setBounds(10,110,100,20);
	    rPriceLbl.setForeground(Color.black);
	    rPriceLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    currencyLbl = new JLabel("£");
	    currencyLbl.setBounds(100,110,100,20);
	    currencyLbl.setForeground(Color.black);
	    currencyLbl.setFont(new Font("serif",Font.BOLD, 18));
	    
	    rPriceFld = new JTextField();
	    rPriceFld.setBounds(120, 110, 150, 25);
	    rPriceFld.setEditable(false);
	    
	    
	    creditNumLbl = new JLabel("CreditCard");
		creditNumLbl.setBounds(320,110,150,20);
		creditNumLbl.setForeground(Color.black);	// setting foreground color of text1 
		creditNumLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		creditNumFld = new JTextField();
		creditNumFld.setBounds(440,110,150,25);
		
		cardExpDateLbl = new JLabel("Expiry Date");
		cardExpDateLbl.setBounds(10,160,100,20);
		cardExpDateLbl.setForeground(Color.black);	// setting foreground color of text1 
		cardExpDateLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		expDate = new JDateChooser();
		expDate.setBounds(120, 160, 150, 25);
		expCalendar = Calendar.getInstance();
		expCalendar.add(Calendar.DATE, 1);
		expDate.setMinSelectableDate(expCalendar.getTime());
		
		cvvLbl = new JLabel("CVV");
		cvvLbl.setBounds(320,160,100,20);
		cvvLbl.setForeground(Color.black);	// setting foreground color of text1 
		cvvLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		cvvFld = new JTextField(3);
		cvvFld.setBounds(440,160,150,25);
		
		
		 // add an action listener to the combo box
        rTypeComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // get the selected item in the combo box
                String selectedItem = (String) rTypeComboBox.getSelectedItem();
             // check if the selected item is not null before comparing
                if (selectedItem != null) {
	                // update the text of rPriceFld based on the selected item
	                if (selectedItem.equals("Single")) {
	                    rPriceFld.setText("30");
	                    numGuestFld.setText("1");
	                    GuestWindowManagement.roomTypeId=1;
	                } else if (selectedItem.equals("Twin")) {
	                    rPriceFld.setText("80");
	                    numGuestFld.setText("4");
	                    GuestWindowManagement.roomTypeId=3;
	                } else if (selectedItem.equals("Double")) {
	                    rPriceFld.setText("50");
	                    numGuestFld.setText("2");
	                    GuestWindowManagement.roomTypeId=2;
	                }
	    	  }
            }
        });

		submitBtn = new JButton("SUBMIT");
		submitBtn.setBounds(150,220,100,30);
		submitBtn.setFont(new Font("serif",Font.BOLD, 17));
		submitBtn.setForeground(Color.black);
		submitBtn.setBackground(Color.green);
		
		
		
		submitBtn.addActionListener(new ActionListener() {
		    @SuppressWarnings("null")
			public void actionPerformed(ActionEvent ae) {
		    	
		    	
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==submitBtn) {		    				    		
		    		
		    		// get the selected check-in and check-out dates
	    	        Date selectedCheckInDate = arrDate.getDate();
	    	        Date selectedCheckOutDate = depDate.getDate();
	    	        Date selectedExpiryDate = expDate.getDate();

	    	        if(selectedCheckInDate!=null&&selectedCheckOutDate!=null&&selectedExpiryDate!=null&&selectedCheckInDate.before(selectedCheckOutDate)) {
	    	        		    	        	    	        
		    	        // convert the dates to sql dates
		    	        java.sql.Date sqlCheckInDate = new java.sql.Date(selectedCheckInDate.getTime());
		    	        java.sql.Date sqlCheckOutDate = new java.sql.Date(selectedCheckOutDate.getTime());
		    	        java.sql.Date sqlExpiryDate = new java.sql.Date(selectedExpiryDate.getTime());
		    	        
		    	  
			    		GuestWindowManagement gwm = new GuestWindowManagement(sqlCheckInDate,sqlCheckOutDate,
			    		Integer.parseInt(numGuestFld.getText()),Integer.parseInt(numGuestFld.getText()),Integer.parseInt(rPriceFld.getText()),
			    		creditNumFld.getText(),sqlExpiryDate,cvvFld.getText());
			    		
			    		if(CustomerLoginManagement.customerTypeId==2) {
			    			boolean result = new GuestWindowController().createBookingNormalCustomer(gwm);
			    					
			    				if(result==true) {
			    					//Save message
			    					JOptionPane.showMessageDialog(createBookFrame, "Request Successful");
			    					updateCustomerTable();
			    			        new GuestWindowController().getPendingBooking();
			    			        
			    			        arrDate.setDate(null);
					    			depDate.setDate(null);
					    			numGuestFld.setText("");
					    			rPriceFld.setText("");
					    			creditNumFld.setText("");
					    			expDate.setDate(null);
					    			cvvFld.setText("");
					    			rTypeComboBox.setSelectedIndex(-1);
					    			
					    			
			    				}
			    				else {
			    					//error message
			    					JOptionPane.showMessageDialog(createBookFrame, "Error to request");
			    				}
			    		}else {
			    			boolean result = new GuestWindowController().createBookingCorporateCustomer(gwm);
	    					
		    				if(result==true) {
		    					//Save message
		    					JOptionPane.showMessageDialog(createBookFrame, "Request Successful");
		    					updateCustomerTable();
				    			new GuestWindowController().getPendingBooking();
				    			
				    			
				    			arrDate.setDate(null);
				    			depDate.setDate(null);
				    			numGuestFld.setText("");
				    			rPriceFld.setText("");
				    			creditNumFld.setText("");
				    			expDate.setDate(null);
				    			cvvFld.setText("");
				    			rTypeComboBox.setSelectedIndex(-1);
				    			
				    			
		    				}
		    				else {
		    					//error message
		    					JOptionPane.showMessageDialog(createBookFrame, "Error to request");
		    				}
			    		}
	    	        }else {
			    		JOptionPane.showMessageDialog(createBookFrame, "Invalid Date!");
			    	}
		    	}
		    }

			public void updateCustomerTable() {
				
				// clear existing data from the model
		        customerModel.setRowCount(0);

		        // populate the table with the updated data
		        ArrayList<GuestWindowManagement> customers = new GuestWindowController().getPendingBooking();

		        for (int i = 0; i < customers.size(); i++) {
		            GuestWindowManagement customer = customers.get(i);
		            String[] rowData = { customer.getFullName(), customer.getArrivalDate().toString(), customer.getDepartureDate().toString(),
		                                 customer.getRoomType().toString(), String.valueOf(customer.getRoomPrice()), customer.getBookingStatus() };
		            customerModel.addRow(rowData);
		        }

		        // notify the table that the data has changed
		        customerModel.fireTableDataChanged();
			}
		});

		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(300,220,100,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		

		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the close button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		createBookFrame.setVisible(false);
		    		
		    	}
		    }
		});
		
		String[] columnNames = {"Full Name","Check-In Date","Check-Out Date","Room Type","Room Price","Booking Status"};
		customerModel = new DefaultTableModel(columnNames, 0);
		bookingTable = new JTable(customerModel);	
		bookingTable.setFont(new Font("serif",Font.BOLD, 12));
		
		scrollPane = new JScrollPane(bookingTable);
		scrollPane.setBounds(5, 275, 590, 124);
		
		 // notify the table that the data has changed
        customerModel.fireTableDataChanged();

	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(rTypeLbl);
	    panel.add(rTypeComboBox);
	    panel.add(numGuestLbl);
	    panel.add(numGuestFld);
	    panel.add(rPriceLbl);
	    panel.add(rPriceFld);
	    panel.add(currencyLbl);
	    panel.add(creditNumLbl);
	    panel.add(creditNumFld);
	    panel.add(cardExpDateLbl);
	    panel.add(expDate);
	    panel.add(cvvLbl);
	    panel.add(cvvFld);
	    panel.add(submitBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    panel.add(bookingTable.getTableHeader());
		
	    
	    
	    createBookFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    createBookFrame.getContentPane().add(panel);
	    
    }
    
    private void initFrame2(JInternalFrame iframe) {
    	
    	JPanel panel;
    	JLabel titleLbl,arrivalDateLbl, departureDateLbl,rTypeLbl,numGuestLbl,rPriceLbl,currencyLbl,bookingLbl;
    	JTextField numGuestFld,rPriceFld,bookingFld;
    	JDateChooser arrDate,depDate;
    	JComboBox <String>rTypeComboBox;
    	JButton updateBtn,deleteBtn,closeBtn;
    	Calendar arrCalendar,depCalendar;
    	
    	viewBookFrame.setSize(700,500);
    	viewBookFrame.setLocation(400,200);
    	viewBookFrame.setResizable(false);
    	viewBookFrame.setLayout(null);
    	viewBookFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	viewBookFrame.setTitle("Booking Form");
	    
	    titleLbl = new JLabel("Booking Form");
	    titleLbl.setBounds(250,0,200,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.black);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(20, 50, 650, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,10,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,10,150,25);
	    arrCalendar = Calendar.getInstance();
	    arrCalendar.setTime(new Date()); // set minimum selectable date to current date
        arrDate.setMinSelectableDate(arrCalendar.getTime());
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(360,10,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();
	    depDate.setBounds(480,10,150,25);
	    depCalendar = Calendar.getInstance();
	    depCalendar.setTime(new Date()); // set minimum selectable date to current date
	    depDate.setMinSelectableDate(depCalendar.getTime());
		
	    rTypeLbl = new JLabel("Room Type");
	    rTypeLbl.setBounds(10,60,100,20);
	    rTypeLbl.setForeground(Color.black);
	    rTypeLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String rType[] = {"Single", "Double", "Twin"};
	    rTypeComboBox = new JComboBox <>(rType);
	    rTypeComboBox.setSelectedIndex(-1);
	    rTypeComboBox.setBounds(120, 60, 150, 25);
	    
	    numGuestLbl = new JLabel("No. of Guest");
	    numGuestLbl.setBounds(360,60,150,20);
	    numGuestLbl.setForeground(Color.black);
	    numGuestLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    numGuestFld = new JTextField();
	    numGuestFld.setBounds(480,60,150,25);
	    numGuestFld.setEditable(false);
	    
	    rPriceLbl = new JLabel("Price/Day");
	    rPriceLbl.setBounds(10,110,100,20);
	    rPriceLbl.setForeground(Color.black);
	    rPriceLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    currencyLbl = new JLabel("£");
	    currencyLbl.setBounds(100,110,100,20);
	    currencyLbl.setForeground(Color.black);
	    currencyLbl.setFont(new Font("serif",Font.BOLD, 18));
	    
	    rPriceFld = new JTextField();
	    rPriceFld.setBounds(120, 110, 150, 25);
	    rPriceFld.setEditable(false);
	    
	    bookingLbl = new JLabel("Booking Id");
	    bookingLbl.setBounds(360,110,100,20);
	    bookingLbl.setForeground(Color.black);
	    bookingLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    bookingFld = new JTextField();
	    bookingFld.setBounds(480, 110, 150, 25);
	    bookingFld.setEditable(false);
	    
	    
	 // add an action listener to the combo box
        rTypeComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                // get the selected item in the combo box
                String selectedItem = (String) rTypeComboBox.getSelectedItem();
                
                // update the text of rPriceFld based on the selected item
                if (selectedItem.equals("Single")) {
                    rPriceFld.setText("30");
                    numGuestFld.setText("1");
                    GuestWindowManagement.roomTypeId=1;
                } else if (selectedItem.equals("Twin")) {
                    rPriceFld.setText("80");
                    numGuestFld.setText("4");
                    GuestWindowManagement.roomTypeId=3;
                } else if (selectedItem.equals("Double")) {
                    rPriceFld.setText("50");
                    numGuestFld.setText("2");
                    GuestWindowManagement.roomTypeId=2;
                }	    	  
            }
        });
	    
		
		updateBtn = new JButton("UPDATE");
		updateBtn.setBounds(120,180,120,30);
		updateBtn.setFont(new Font("serif",Font.BOLD, 17));
		updateBtn.setForeground(Color.black);
		updateBtn.setBackground(Color.green);
		
		updateBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==updateBtn) {
		    		
		    		Date selectedCheckInDate = arrDate.getDate();
	    	        Date selectedCheckOutDate = depDate.getDate();
	    	        
	    	        if(selectedCheckInDate!=null&&selectedCheckOutDate!=null&&selectedCheckInDate.before(selectedCheckOutDate)) {	    	        	  
	    	        
	    	        // convert the dates to sql dates
	    	        java.sql.Date sqlCheckInDate = new java.sql.Date(selectedCheckInDate.getTime());
	    	        java.sql.Date sqlCheckOutDate = new java.sql.Date(selectedCheckOutDate.getTime());
	    	      
		    		GuestWindowManagement gwm = new GuestWindowManagement(Integer.parseInt(bookingFld.getText()),sqlCheckInDate,sqlCheckOutDate,
		    		Integer.parseInt(numGuestFld.getText()),Integer.parseInt(rPriceFld.getText()));
		    		
		    		boolean result = new GuestWindowController().updateBooking(gwm);
		    		if(result==true) {
		    		
		    			JOptionPane.showMessageDialog(viewBookFrame, "Update Successful");		    			
		    			
		    			updateBookingTable();
				        new GuestWindowController().getViewBooking();
		    			
		    			arrDate.setDate(null);
		    			depDate.setDate(null);
		    			numGuestFld.setText("");
		    			rPriceFld.setText("");
		    			bookingFld.setText("");
		    			rTypeComboBox.setSelectedIndex(-1);
		    			
		    		}else {
		    			JOptionPane.showMessageDialog(viewBookFrame, "Fail to Update");
		    			}
	    	        }else {
	    	        	JOptionPane.showMessageDialog(viewBookFrame, "Invalid Date!");	  	    	      
	    	        }
		    	}
		    }
		    public void updateBookingTable() {
				
				// clear existing data from the model
		        viewModel.setRowCount(0);

		        // populate the table with the updated data
		        ArrayList<GuestWindowManagement> customers = new GuestWindowController().getViewBooking();

		        for (int i = 0; i < customers.size(); i++) {
		            GuestWindowManagement customer = customers.get(i);
		            String[] rowData = { customer.getFullName(),String.valueOf(customer.getBookingId()), customer.getArrivalDate().toString(), customer.getDepartureDate().toString(),
		                                 customer.getRoomType().toString(), String.valueOf(customer.getRoomPrice()), customer.getBookingStatus() };
		            viewModel.addRow(rowData);
		        }

		        // notify the table that the data has changed
		        viewModel.fireTableDataChanged();
			}
		});
		
		deleteBtn = new JButton("DELETE");
		deleteBtn.setBounds(270,180,120,30);
		deleteBtn.setFont(new Font("serif",Font.BOLD, 17));
		deleteBtn.setForeground(Color.black);
		deleteBtn.setBackground(Color.red);
		
		deleteBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==deleteBtn) {
		    		
		    		GuestWindowManagement gwm = new GuestWindowManagement(Integer.parseInt(bookingFld.getText()));
		    		boolean result = new GuestWindowController().deleteBooking(gwm);
		    		if(result==true) {
		    		
		    			JOptionPane.showMessageDialog(viewBookFrame, "Booking Deleted Successfully");
		    			arrDate.setDate(null);
		    			depDate.setDate(null);
		    			rTypeComboBox.setSelectedIndex(-1);
		    			numGuestFld.setText("");
		    			rPriceFld.setText("");
		    			bookingFld.setText("");
		    			
		    			updateBookingTable();
		    			new GuestWindowController().getViewBooking();
		    			
		    		}else {
		    			JOptionPane.showMessageDialog(viewBookFrame, "Fail to Delete Booking");
		    		}
		    	}
		    }
		    public void updateBookingTable() {
				
				// clear existing data from the model
		        viewModel.setRowCount(0);

		        // populate the table with the updated data
		        ArrayList<GuestWindowManagement> customers = new GuestWindowController().getViewBooking();

		        for (int i = 0; i < customers.size(); i++) {
		            GuestWindowManagement customer = customers.get(i);
		            String[] rowData = { customer.getFullName(),String.valueOf(customer.getBookingId()), customer.getArrivalDate().toString(), customer.getDepartureDate().toString(),
		                                 customer.getRoomType().toString(), String.valueOf(customer.getRoomPrice()), customer.getBookingStatus() };
		            viewModel.addRow(rowData);
		        }

		        // notify the table that the data has changed
		        viewModel.fireTableDataChanged();
			}
		});
		
		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(420,180,120,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		
		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the close button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		viewBookFrame.setVisible(false);
		    		
		    	}
		    }
		});
		
		String[] columnNames = {"Full Name","Booking Id","Check-In Date","Check-Out Date","Room Type","Room Price","Booking Status"};
		viewModel = new DefaultTableModel(columnNames, 0);
		
		bookingTable = new JTable(viewModel);
		scrollPane = new JScrollPane(bookingTable);
		scrollPane.setBounds(5, 230, 640, 164);
	
        viewModel.setRowCount(0);
        // populate the table with the updated data
        ArrayList<GuestWindowManagement> customers = new GuestWindowController().getViewBooking();
        
        for (int i = 0; i < customers.size(); i++) {
            GuestWindowManagement customer = customers.get(i);
            String[] rowData = { customer.getFullName(),Integer.toString(customer.getBookingId()), customer.getArrivalDate().toString(), customer.getDepartureDate().toString(),
                                 customer.getRoomType().toString(), String.valueOf(customer.getRoomPrice()), customer.getBookingStatus() };
            viewModel.addRow(rowData);
        }

        // notify the table that the data has changed
        viewModel.fireTableDataChanged();
		
	
		// Add a ListSelectionListener to the table
		bookingTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		    public void valueChanged(ListSelectionEvent event) {
		        if (!event.getValueIsAdjusting()) {
		        	// Get the selected row index
		            int rowIndex = bookingTable.getSelectedRow();
		            if (rowIndex >= 0) { // If a row is selected
		            	
		            	String bookingId = (String) bookingTable.getValueAt(rowIndex, 1);
		            	String arrivalDateStr = (String) bookingTable.getValueAt(rowIndex, 2);
		            	String departureDateStr = (String) bookingTable.getValueAt(rowIndex, 3);

		            	DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Replace the format string with your own date format

		            	Date arrivalDate = null;
		            	Date departureDate = null;

		            	try {
		            	    arrivalDate = df.parse(arrivalDateStr);
		            	    departureDate = df.parse(departureDateStr);
		            	} catch (ParseException e) {
		            	    e.printStackTrace();
		            	}

		            	 String roomType = (String) bookingTable.getValueAt(rowIndex, 4);
		                 // Set the values of the fields to the selected row values
		            	 bookingFld.setText(bookingId);
		            	 arrDate.setDate(arrivalDate);
		                 depDate.setDate(departureDate);		                 		                 
		                 rTypeComboBox.setSelectedItem(roomType);
		                 
		                 
		                 if(roomType.equals("Single")) {
		                	 rPriceFld.setText("30");
		                     numGuestFld.setText("1");
		                     GuestWindowManagement.setRoomTypeId(1);
		                 }else if(roomType.equals("Double")) {
		                	 rPriceFld.setText("50");
		                     numGuestFld.setText("2");
		                     GuestWindowManagement.setRoomTypeId(2);
		                 }else if(roomType.equals("Twin")) {
		                	 rPriceFld.setText("80");
		                     numGuestFld.setText("4");
		                     GuestWindowManagement.setRoomTypeId(3);
		                 }
		            }	
		        }
		    }
		});
		
	        
        
	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(rTypeLbl);
	    panel.add(rTypeComboBox);
	    panel.add(numGuestLbl);
	    panel.add(numGuestFld);
	    panel.add(rPriceLbl);
	    panel.add(currencyLbl);
	    panel.add(rPriceFld);
	    panel.add(bookingLbl);
	    panel.add(bookingFld);
	    panel.add(updateBtn);
	    panel.add(deleteBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    
	    
	    viewBookFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    viewBookFrame.getContentPane().add(panel);
	
	}
    

    private void initFrame3(JInternalFrame iframe) {
    	
    	JPanel panel;
    	ImageIcon icon;
    	JLabel imageLbl,titleLbl,nameLbl,cardNumLbl,expDateLbl,cvvLbl,amountLbl,priceLbl;
    	JTextField nameFld,cardNumFld,cvvFld,amountFld;
    	JButton submitBtn,closeBtn;
    	JDateChooser expDate;
    	
    	onlineFrame.setSize(700,500);
    	onlineFrame.setLocation(400,200);
    	onlineFrame.setResizable(false);
    	onlineFrame.setLayout(null);
    	onlineFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	onlineFrame.setTitle("Online Payment");
	    
	    titleLbl = new JLabel("Card Details");
	    titleLbl.setBounds(250,0,200,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.black);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(20, 50, 650, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    icon = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\icons\\yellow.png");
	    imageLbl = new JLabel(icon);
	    imageLbl.setBounds(0, 0, 700, 500); // set the position and size of the label
	    
	    nameLbl = new JLabel("Card Holder's Name");
	    nameLbl.setBounds(50, 10, 150, 25);
	    
	    nameFld = new JTextField();
	    nameFld.setBounds(200,10,300,25);
	    	
	    // Create labels for card details
        cardNumLbl = new JLabel("Card Number:");
        cardNumLbl.setBounds(50, 50, 150, 25);
        
        expDateLbl = new JLabel("Expiration Date:");
        expDateLbl.setBounds(50, 100, 150, 25);
       
        cvvLbl = new JLabel("CVV:");
        cvvLbl.setBounds(50, 150, 150, 25);
        
        amountLbl = new JLabel("Total Amount");
        amountLbl.setBounds(50,200,150,25);
        
        priceLbl = new JLabel("£");
        priceLbl.setBounds(180,195,50,30);
        priceLbl.setFont(new Font("serif",Font.BOLD,17));
        
        // Create text fields for entering card details
        cardNumFld = new JTextField();
        cardNumFld.setBounds(200, 50, 200, 25);
        
        expDate = new JDateChooser();
        expDate.setBounds(200, 100, 100, 25);
        Calendar expCalendar = Calendar.getInstance();
		expCalendar.add(Calendar.DATE, 1);
		expDate.setMinSelectableDate(expCalendar.getTime());

        cvvFld = new JTextField();
        cvvFld.setBounds(200, 150, 60, 25);
        
        amountFld = new JTextField();
        amountFld.setBounds(200,200,60,25);
       
        // Create a button for submitting card details
        submitBtn = new JButton("PAY");
        submitBtn.setBounds(50, 270, 90, 30);
        submitBtn.setFont(new Font("serif",Font.BOLD, 17));
        submitBtn.setForeground(Color.black);
        submitBtn.setBackground(Color.green);
        submitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
//            	GuestWindowManagement gwm = new GuestWindowManagement();
//            	boolean result = new GuestWindowJDBC().updateBookingStatus(gwm);
//            	if(result==true) {
            		JOptionPane.showMessageDialog(onlineFrame, "Payment Successful");
//            	}else {
//            		JOptionPane.showMessageDialog(onlineFrame, "Payment Failed!");
//            	}
            }
        });
        
        closeBtn = new JButton("CLOSE");
        closeBtn.setBounds(170, 270, 100, 30);
        closeBtn.setFont(new Font("serif",Font.BOLD, 17));
        closeBtn.setForeground(Color.black);
        closeBtn.setBackground(Color.red);
        closeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==closeBtn) {
                	onlineFrame.setVisible(false);
                }
            }
        });
        
        // Add panel and title label to the internal frame
        onlineFrame.add(panel);
        onlineFrame.add(titleLbl);
        panel.add(imageLbl); // add the label to the frame

        imageLbl.add(nameLbl);
        imageLbl.add(nameFld);
        
        imageLbl.add(cardNumLbl);
        imageLbl.add(cardNumFld);
        
        imageLbl.add(expDateLbl);
        imageLbl.add(expDate);
        
        imageLbl.add(cvvLbl);
        imageLbl.add(cvvFld);
        
        imageLbl.add(amountLbl);
        imageLbl.add(priceLbl);
        imageLbl.add(amountFld);
        
        imageLbl.add(submitBtn);
        imageLbl.add(closeBtn);
        
        
       
    }
	
	@Override
    public void actionPerformed(ActionEvent ae) {
        // add action listener code here
    	if (ae.getSource() == create) {
    		if (!desktopPane.isAncestorOf(createBookFrame)) {
 		       desktopPane.add(createBookFrame, JLayeredPane.DEFAULT_LAYER);
 		   } else {
 		       desktopPane.setLayer(createBookFrame, JLayeredPane.DEFAULT_LAYER);
 		   }
    		createBookFrame.setVisible(true);
 		}
    	else if (ae.getSource() == view) {
    		if (!desktopPane.isAncestorOf(viewBookFrame)) {
    			desktopPane.add(viewBookFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(viewBookFrame, JLayeredPane.DEFAULT_LAYER);
    		}
    		viewBookFrame.setVisible(true);
    		}
    	else if(ae.getSource()==online) {
    		if (!desktopPane.isAncestorOf(onlineFrame)) {
    			desktopPane.add(onlineFrame, JLayeredPane.DEFAULT_LAYER);
 		   } else {
 			   desktopPane.setLayer(onlineFrame, JLayeredPane.DEFAULT_LAYER);
 		   }
    		onlineFrame.setVisible(true);
 		}
    	
    	else if(ae.getSource()==close) {
    		dispose();
    		MainWindow mw = new MainWindow();
    		mw.setVisible(true);
    	}
    }
	public static void main(String[] args) {
		CustomerLoginManagement login = new CustomerLoginManagement();
		GuestWindow gWindow = new GuestWindow(login);
	}
}
