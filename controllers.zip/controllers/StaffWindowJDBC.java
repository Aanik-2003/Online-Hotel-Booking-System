package controllers;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import models.GuestWindowManagement;
import models.CustomerLoginManagement;
import models.StaffLoginManagement;
import models.StaffWindowManagement;

public class StaffWindowJDBC {

	public ArrayList<StaffWindowManagement> getPendingBooking() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select c.customer_id,b.booking_id, b.checkIn_date, b.checkOut_date, rt.room_type_name, bs.booking_status_name \r\n"
				+ "from assignment1.table_booking b \r\n"
				+ "inner join table_customer c on c.customer_id=b.customer_id \r\n"
				+ "inner join table_booking_status bs on bs.booking_status_id=b.booking_status_id\r\n"
				+ "inner join table_room_type rt on b.room_type_id=rt.room_type_id \r\n"
				+ "where bs.booking_status_name='Pending';";
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);	  
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				int cId = rs.getInt("customer_id");
				int bId = rs.getInt("booking_id");			
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");				
				String bookingStatus = rs.getString("booking_status_name");

				swm.setCustomerId(cId);
				swm.setBookingId(bId);			
				swm.setRoomType(roomType);		
				swm.setArrivalDate(arrDate);
				swm.setDepartureDate(depDate);
				swm.setBookingStatus(bookingStatus);
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public boolean confirmBooking(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "update table_booking set booking_status_id=?, room_number =?,room_status_id=?,staff_id=? where customer_id=? and booking_id=?;";
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setInt(1, 1);	
	        pst.setInt(2, swm.getRoomNumber());
	        pst.setInt(3, 5);
	        pst.setInt(4, StaffLoginManagement.staffId);
	        pst.setInt(5, swm.getCustomerId());	       
	        pst.setInt(6, swm.getBookingId());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> checkRoom() {
        ArrayList<StaffWindowManagement> roomNumbers = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root", "Mniakm#1");
            String query = "select room_number from table_room where room_status_id = ? and room_type_id =?;";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, 1);
            pst.setInt(2, StaffWindowManagement.getRoomTypeId());
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
            	StaffWindowManagement swm = new StaffWindowManagement();
            	
                int roomNumber = rs.getInt("room_number");
                
                swm.setRoomNumber(roomNumber);
                
                roomNumbers.add(swm);
                
            }
            pst.close();
            conn.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return roomNumbers;
    }
	
	public ArrayList<StaffWindowManagement> getCheckedInRoomNumbers() {
        ArrayList<StaffWindowManagement> roomNumbers = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root", "Mniakm#1");
            String query = "select r.room_number\r\n"
            		+ "from assignment1.table_room r\r\n"
            		+ "join table_booking b on b.room_number=r.room_number\r\n"
            		+ "join table_customer c on c.customer_id=b.customer_id\r\n"
            		+ "join table_booking_status bs on bs.booking_status_id=b.booking_status_id\r\n"
            		+ "where bs.booking_status_name='Checked In';";
            
            PreparedStatement pst = conn.prepareStatement(query);
           
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
            	StaffWindowManagement swm = new StaffWindowManagement();
            	
                int roomNumber = rs.getInt("room_number");
                
                swm.setRoomNumber(roomNumber);
                
                roomNumbers.add(swm);
                
            }
            pst.close();
            conn.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return roomNumbers;
    }
	public ArrayList<String> getCustomerName(String selectedRoomNumber) {
	    ArrayList<String> result = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root", "Mniakm#1");
            String query = "SELECT CONCAT(c.first_name, ' ', c.last_name) AS full_name \r\n"
            		+ "FROM assignment1.table_customer c \r\n"
            		+ "JOIN table_booking b ON b.customer_id = c.customer_id \r\n"
            		+ "JOIN table_room r ON r.room_number = b.room_number \r\n"
            		+ "JOIN table_booking_status bs ON bs.booking_status_id = b.booking_status_id \r\n"
            		+ "WHERE r.room_number = ? AND bs.booking_status_name = 'Checked In';";
            
            PreparedStatement pst = conn.prepareStatement(query);
            
            pst.setString(1, selectedRoomNumber);
            
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                String customerName = rs.getString("full_name");
                result.add(customerName);
            }
            pst.close();
            conn.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return result;
    }


	public ArrayList<StaffWindowManagement> getConfirmedBooking() {
        ArrayList<StaffWindowManagement> confirmedBooking = new ArrayList<>();
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root", "Mniakm#1");
            String query = "select c.customer_id,concat(c.first_name,' ',c.last_name) as full_name,b.checkIn_date,b.checkOut_date,rt.room_type_name,b.room_number,bs.booking_status_name,s.first_name\r\n"
            		+ "from assignment1.table_booking b\r\n"
            		+ "join table_customer c on c.customer_id=b.customer_id\r\n"
            		+ "join table_room_type rt on b.room_type_id=rt.room_type_id\r\n"
            		+ "join table_staff s on s.staff_id=b.staff_id\r\n"
            		+ "join table_booking_status bs on bs.booking_status_id=b.booking_status_id\r\n"
            		+ "where bs.booking_status_name='Confirmed' group by concat(c.first_name, ' ', c.last_name),b.booking_id,b.checkIn_date,b.checkOut_date, \r\n"
            		+ "rt.room_type_name, b.room_number, bs.booking_status_name,s.first_name;";
            
            PreparedStatement pst = conn.prepareStatement(query);
           
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
            	StaffWindowManagement swm = new StaffWindowManagement();
            	
            	
            	int cId = rs.getInt("customer_id");
            	String fName = rs.getString("full_name");
            	Date arrDate = rs.getDate("checkIn_date");
            	Date depDate = rs.getDate("checkOut_date");
            	String roomType = rs.getString("room_type_name");
                int roomNumber = rs.getInt("room_number");
                String bsName = rs.getString("booking_status_name");
                String sName = rs.getString("first_name");
                
                swm.setCustomerId(cId);
                swm.setCustomerName(fName);
                swm.setArrivalDate(arrDate);
                swm.setDepartureDate(depDate);
                swm.setRoomType(roomType);
                swm.setRoomNumber(roomNumber);
                swm.setBookingStatus(bsName);
                swm.setStaffName(sName);
                
                confirmedBooking.add(swm);
                
            }
            pst.close();
            conn.close();
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
        return confirmedBooking;
    }
	
	public boolean deleteBooking(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "delete from table_booking where customer_id = ? and booking_id = ?;";
	        PreparedStatement pst = conn.prepareStatement(query);
	        
	        pst.setInt(1, swm.getCustomerId());
	        pst.setInt(2, swm.getBookingId());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> getReservedTable() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select b.customer_id,b.booking_id, b.checkIn_date, b.checkOut_date, rt.room_type_name,b.room_number, rs.room_status_name \r\n"
				+ "from assignment1.table_booking b \r\n"
				+ "inner join table_room_type rt on b.room_type_id=rt.room_type_id\r\n"
				+ "inner join table_room_status rs on rs.room_status_id=b.room_status_id \r\n"
				+ "where rs.room_status_name='Reserved';";
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);	  
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				int cId = rs.getInt("customer_id");
				int bId = rs.getInt("booking_id");			
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");	
				int roomNum = rs.getInt("room_number");
				String roomStatus = rs.getString("room_status_name");

				swm.setCustomerId(cId);
				swm.setBookingId(bId);			
				swm.setRoomType(roomType);		
				swm.setArrivalDate(arrDate);
				swm.setDepartureDate(depDate);
				swm.setRoomNumber(roomNum);
				swm.setRoomStatus(roomStatus);
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public boolean confirmCheckIn(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "update table_booking set booking_status_id=?, room_status_id=? where customer_id=? and booking_id =?;";
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setInt(1, 4);
	        pst.setInt(2, 2);
	        pst.setInt(3, swm.getCustomerId());
	        pst.setInt(4, swm.getBookingId());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> getCheckInTable() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select c.customer_id,b.booking_id, concat(c.first_name,' ',c.last_name) as full_name,b.checkIn_date,b.checkOut_date,rt.room_type_name,b.room_number,\r\n"
				+ "bs.booking_status_name\r\n"
				+ "from assignment1.table_booking b\r\n"
				+ "join table_customer c on c.customer_id=b.customer_id\r\n"
				+ "join table_room_type rt on b.room_type_id=rt.room_type_id\r\n"
				+ "join table_booking_status bs on bs.booking_status_id=b.booking_status_id\r\n"
				+ "where bs.booking_status_name='Checked In' group by concat(c.first_name, ' ', c.last_name),c.customer_id,b.booking_id,b.checkIn_date,b.checkOut_date, \r\n"
				+ "rt.room_type_name, b.room_number, bs.booking_status_name;";
				
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);	  
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				int cId = rs.getInt("customer_id");
				int bId = rs.getInt("booking_id");
				String fName = rs.getString("full_name");
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");	
				int roomNum = rs.getInt("room_number");
				String bStatus = rs.getString("booking_status_name");

				swm.setCustomerId(cId);
				swm.setBookingId(bId);
				swm.setFullName(fName);		
				swm.setRoomType(roomType);		
				swm.setArrivalDate(arrDate);
				swm.setDepartureDate(depDate);
				swm.setRoomNumber(roomNum);
				swm.setBookingStatus(bStatus);
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public boolean confirmCheckOut(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "update table_booking set booking_status_id=?, room_status_id=? where customer_id=? and booking_id =?;";
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setInt(1, 5);
	        pst.setInt(2, 1);
	        pst.setInt(3, swm.getCustomerId());
	        pst.setInt(4, swm.getBookingId());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> getCheckOut() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select concat(c.first_name,' ',c.last_name) as full_name, b.checkIn_date, b.checkOut_date, rt.room_type_name,b.room_number, bs.booking_status_name \r\n"
				+ "from assignment1.table_booking b \r\n"
				+ "join table_customer c on c.customer_id=b.customer_id\r\n"
				+ "join table_room_type rt on b.room_type_id=rt.room_type_id\r\n"
				+ "join table_booking_status bs on bs.booking_status_id=b.booking_status_id \r\n"
				+ "where bs.booking_status_name='Checked Out' group by concat(c.first_name,' ',c.last_name),b.booking_id,b.checkIn_date, \r\n"
				+ "b.checkOut_date, rt.room_type_name,b.room_number, bs.booking_status_name;";
				
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);	  
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				
				String fName = rs.getString("full_name");
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");	
				int roomNum = rs.getInt("room_number");
				String bStatus = rs.getString("booking_status_name");

				
				swm.setFullName(fName);		
				swm.setRoomType(roomType);		
				swm.setArrivalDate(arrDate);
				swm.setDepartureDate(depDate);
				swm.setRoomNumber(roomNum);
				swm.setBookingStatus(bStatus);
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public boolean addExtService(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "insert into extra_service_room (extra_service_id,quantity,total,room_number) values(?,?,?,?);";
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        		
	        pst.setInt(1, swm.getExtServiceId());
	        pst.setInt(2, swm.getQuantity());
	        pst.setInt(3, swm.getTotal());
	        pst.setInt(4, swm.getRoomNumber());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> getExtraServiceTable() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select concat(c.first_name,' ',c.last_name)as full_name,r.room_number,s.service_name,sr.quantity,s.service_charge,sr.total\r\n"
				+ "from assignment1.table_booking b \r\n"
				+ "join table_customer c on c.customer_id=b.customer_id\r\n"
				+ "join table_room r on r.room_number=b.room_number\r\n"
				+ "join extra_service_room sr on sr.room_number=r.room_number\r\n"
				+ "join extra_service s on s.extra_service_id=sr.extra_service_id;";
				
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	       
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				String fName = rs.getString("full_name");
				int roomNum = rs.getInt("room_number");
				String serviceName = rs.getString("service_name");
				int quantity = rs.getInt("quantity");
				int rate = rs.getInt("service_charge");
				int total = rs.getInt("total");
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				swm.setFullName(fName);		
				swm.setRoomNumber(roomNum);
				swm.setServiceName(serviceName);
				swm.setQuantity(quantity);
				swm.setRate(rate);
				swm.setTotal(total);
				
				
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public boolean addRBService(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "insert into rb_service_room(rb_service_id,room_number,quantity,total) values(?,?,?,?);";
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        		
	        pst.setInt(1, swm.getRBServiceId());
	        pst.setInt(2, swm.getRoomNumber());
	        pst.setInt(3, swm.getQuantity());
	        pst.setInt(4, swm.getTotal());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<StaffWindowManagement> getRBServiceTable() {
		ArrayList customers = new ArrayList<StaffWindowManagement>();
		String query = "select concat(c.first_name,' ',c.last_name)as full_name,r.room_number,rbs.item_name,rbr.quantity,rbs.item_price,rbr.total\r\n"
				+ "from assignment1.table_booking b \r\n"
				+ "join table_customer c on c.customer_id=b.customer_id\r\n"
				+ "join table_room r on r.room_number=b.room_number\r\n"
				+ "join rb_service_room rbr on rbr.room_number=r.room_number\r\n"
				+ "join rb_service rbs on rbs.rb_service_id=rbr.rb_service_id;";
				
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	       
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				String fName = rs.getString("full_name");
				int roomNum = rs.getInt("room_number");
				String serviceName = rs.getString("item_name");
				int quantity = rs.getInt("quantity");
				int rate = rs.getInt("item_price");
				int total = rs.getInt("total");
				
				StaffWindowManagement swm = new StaffWindowManagement();
				
				swm.setFullName(fName);		
				swm.setRoomNumber(roomNum);
				swm.setServiceName(serviceName);
				swm.setQuantity(quantity);
				swm.setRate(rate);
				swm.setTotal(total);
				
				
				
				customers.add(swm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	public boolean addBill(StaffWindowManagement swm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "insert into table_billing(billing_date,room_number)\r\n"
	        		+ "values(?,?);";
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setDate(1, (Date) swm.getDepartureDate());
	        pst.setInt(2, swm.getRoomNumber());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	public ArrayList<StaffWindowManagement> getBill() {
		ArrayList <StaffWindowManagement>customers = new ArrayList<StaffWindowManagement>();
		String query = "select bl.billing_id,bl.billing_date,concat(c.first_name,' ',c.last_name)as full_name,\r\n"
				+ "concat(c.address_line1,', ',c.country)as address,c.email,b.room_number,rt.room_type_name,b.checkIn_date,b.checkOut_date,\r\n"
				+ "rt.price_per_day,es.service_name,es.service_charge,esr.quantity as esr_qty,esr.total as esr_total,rbs.item_name,rbs.item_price,\r\n"
				+ "rbsr.quantity as rbsr_qty,rbsr.total as rbsr_total,\r\n"
				+ "sum(rt.price_per_day*(b.checkOut_date-b.checkIn_date)) as room_price,\r\n"
				+ "sum((rt.price_per_day*(b.checkOut_date-b.checkIn_date))+esr.total+rbsr.total) as grand_total\r\n"
				+ "from assignment1.table_booking b\r\n"
				+ "left join table_customer c on c.customer_id=b.customer_id\r\n"
				+ "left join table_room_type rt on rt.room_type_id=b.room_type_id\r\n"
				+ "left join table_room r on r.room_number=b.room_number\r\n"
				+ "left join table_billing bl on bl.room_number=b.room_number\r\n"
				+ "left join extra_service_room esr on esr.room_number = r.room_number\r\n"
				+ "left join extra_service es on es.extra_service_id=esr.extra_service_id\r\n"
				+ "left join rb_service_room rbsr on rbsr.room_number=r.room_number\r\n"
				+ "left join rb_service rbs on rbs.rb_service_id=rbsr.rb_service_id\r\n"
				+ "where r.room_number=? group by bl.billing_id,bl.billing_date,concat(c.first_name,' ',c.last_name),\r\n"
				+ "concat(c.address_line1,', ',c.country),c.email,b.room_number,rt.room_type_name,b.checkIn_date,b.checkOut_date,\r\n"
				+ "rt.price_per_day,es.service_name,es.service_charge,esr.quantity,esr.total,rbs.item_name,rbs.item_price,rbsr.quantity,rbsr.total;";
		
		
		
//		StaffWindowManagement swm = new StaffWindowManagement();
		try {
			
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	    
	        pst.setInt(1, 9);
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				StaffWindowManagement sm = new StaffWindowManagement();
				
				int billId = rs.getInt("billing_id");
				Date billDate = rs.getDate("billing_date");
				String fName = rs.getString("full_name");
				String address = rs.getString("address");
				String email = rs.getString("email");
				int roomNum = rs.getInt("room_number");
				String rType= rs.getString("room_type_name");
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				int perNight = rs.getInt("price_per_day");
				String sName = rs.getString("service_name");
				int sQty = rs.getInt("esr_qty");
				int sCharge = rs.getInt("service_charge");
				int sTotal = rs.getInt("esr_total");
				String iName = rs.getString("item_name");
				int iPrice = rs.getInt("item_price");
				int iQty = rs.getInt("rbsr_qty");
				int iTotal = rs.getInt("rbsr_total");
				int rPrice = rs.getInt("room_price");
				int gTotal = rs.getInt("grand_total");
				
				sm.setBillingId(billId);
				sm.setBillingDate(billDate);
				sm.setFullName(fName);
				sm.setAddress(address);
				sm.setEmail(email);
				sm.setRoomNumber(roomNum);
				sm.setRoomType(rType);
				sm.setArrivalDate(arrDate);
				sm.setDepartureDate(depDate);
				sm.setRoomRate(perNight);
				sm.setServiceName(sName);
				sm.setSQuantity(sQty);
				sm.setSCharge(sCharge);
				sm.setSTotal(sTotal);
				sm.setIName(iName);
				sm.setIPrice(iPrice);
				sm.setIQty(iQty);
				sm.setITotal(iTotal);
				sm.setRoomPrice(rPrice);
				sm.setGrandTotal(gTotal);
				
				customers.add(sm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
}
