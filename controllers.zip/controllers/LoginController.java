package controllers;

import models.CustomerLoginManagement;

public class LoginController {

private CustomerLoginManagement login;
	
	public LoginController() {
		this.login = new CustomerLoginManagement();
	}
	public LoginController(CustomerLoginManagement login) {
		this.login = login;
	}
	public CustomerLoginManagement getUser() {
		return login;
	}
	public void setUser(CustomerLoginManagement login) {
		this.login = login;
	}
	public void nonCorporateCustomerLogin() {
		this.login = new LoginJDBC().nonCorporateCustomerLogin(this.login);
	}
	public void corporateCustomerLogin() {
		this.login = new LoginJDBC().corporateCustomerLogin(this.login);
	}
}
