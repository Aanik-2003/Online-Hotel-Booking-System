package controllers;

import java.util.ArrayList;

import models.GuestWindowManagement;

public class GuestWindowController {
	
	public boolean createBookingNormalCustomer(GuestWindowManagement gwm) {
		boolean result = new GuestWindowJDBC().createBookingNormalCustomer(gwm);
		return result;
	}
	
	public boolean createBookingCorporateCustomer(GuestWindowManagement gwm) {
		boolean result = new GuestWindowJDBC().createBookingCorporateCustomer(gwm);
		return result;
	}
	
	public ArrayList getPendingBooking() {
		ArrayList result = new GuestWindowJDBC().getPendingBooking();
		return result;
	}
	
	public ArrayList getViewBooking() {
		ArrayList result = new GuestWindowJDBC().getViewBooking();
		return result;
	}
	
	public boolean updateBooking(GuestWindowManagement gwm) {
		boolean result = new GuestWindowJDBC().updateBooking(gwm);
		return result;
	}
	
	public boolean deleteBooking(GuestWindowManagement gwm) {
		boolean result = new GuestWindowJDBC().deleteBooking(gwm);
		return result;
	}
}
