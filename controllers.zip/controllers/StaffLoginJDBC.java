package controllers;

import java.sql.*;

import models.StaffLoginManagement;

public class StaffLoginJDBC {
	
public StaffLoginManagement staffLogin(StaffLoginManagement staffLogin) {
		
		String sql = "select * from table_staff where email = ? and password = ?";
		
			try {
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1","root","Mniakm#1");
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setString(1, staffLogin.getEmail());
				pst.setString(2, staffLogin.getPassword());
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()) {
					staffLogin.setStaffId(rs.getInt("staff_id"));
					staffLogin.setUser(true);
				}
			}
			catch(Exception ex) {
				System.out.println("Error: "+ex.getMessage());
			}
		return staffLogin;
	
	}

}
