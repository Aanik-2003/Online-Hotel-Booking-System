package controllers;

import java.util.ArrayList;

import models.RegisterManagement;

public class RegisterController {
	
	public ArrayList getNonCorporateCustomers() {
		ArrayList result = new RegisterJDBC().getNonCorporateCustomer();
		return result;
	}
	
	public boolean saveNonCorporateCustomer(RegisterManagement register) {
		boolean result = new RegisterJDBC().saveNonCorporateCustomer(register);
		return result;
	}
	
	public boolean saveCorporateCustomer(RegisterManagement register) {
		boolean result = new RegisterJDBC().saveCorporateCustomer(register);
		return result;
	}
	
}
