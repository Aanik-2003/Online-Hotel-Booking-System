package controllers;

import java.sql.*;

import models.CustomerLoginManagement;

public class LoginJDBC {
	
	public CustomerLoginManagement nonCorporateCustomerLogin(CustomerLoginManagement login) {
		
		String sql = "select * from table_customer where email = ? and password = ?";
		
			try {
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1","root","Mniakm#1");
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setString(1, login.getEmail());
				pst.setString(2, login.getPassword());
				
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()) {
					CustomerLoginManagement.setCustomerId(rs.getInt("customer_id"));
					login.setFirstName(rs.getString("first_name"));
					CustomerLoginManagement.setCustomerTypeId(rs.getInt("customer_type_id"));
				
					login.setUser(true);	 
				}
			}
			catch(Exception ex) {
				System.out.println("Error: "+ex.getMessage());
			}
		 return login;
	
	}
	
	
public CustomerLoginManagement corporateCustomerLogin(CustomerLoginManagement login) {
		
		String sql = "select * from table_customer where email = ? and password = ?";
		
			try {
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1","root","Mniakm#1");
				PreparedStatement pst = conn.prepareStatement(sql);
				pst.setString(1, login.getEmail());
				pst.setString(2, login.getPassword());
				
				ResultSet rs = pst.executeQuery();
				
				while(rs.next()) {
					CustomerLoginManagement.setCustomerId(rs.getInt("customer_id"));
					login.setFirstName(rs.getString("first_name"));
					login.setUser(true);
					CustomerLoginManagement.setCustomerTypeId(rs.getInt("customer_type_id"));
				}
			}
			catch(Exception ex) {
				System.out.println("Error: "+ex.getMessage());
			}
		return login;
	
	}
}
