package controllers;

import java.util.ArrayList;

import models.StaffWindowManagement;


public class StaffWindowController {
	
	public ArrayList getPendingBooking() {
		ArrayList result = new StaffWindowJDBC().getPendingBooking();
		return result;
	}
	
	public ArrayList checkRoom() {
		ArrayList result = new StaffWindowJDBC().checkRoom();
		return result;
	}
	
	public boolean confirmBooking(StaffWindowManagement swm) {
		boolean result = new StaffWindowJDBC().confirmBooking(swm);
		return result;
	}
	
	public ArrayList getConfirmedBooking() {
		ArrayList result = new StaffWindowJDBC().getConfirmedBooking();
		return result;
	}
	
	public boolean deleteBooking(StaffWindowManagement swm) {
		boolean result = new StaffWindowJDBC().deleteBooking(swm);
		return result;
	}
	
	public ArrayList getReservedTable() {
		ArrayList result = new StaffWindowJDBC().getReservedTable();
		return result;
	}
	
	public boolean confirmCheckIn(StaffWindowManagement swm) {
		boolean result = new StaffWindowJDBC().confirmCheckIn(swm);
		return result;
	}
	public ArrayList getCheckInTable() {
		ArrayList result = new StaffWindowJDBC().getCheckInTable();
		return result;
	}
	public boolean confirmCheckOut(StaffWindowManagement swm) {
		boolean result = new StaffWindowJDBC().confirmCheckOut(swm);
		return result;
	}
	public ArrayList getCheckOut() {
		ArrayList result = new StaffWindowJDBC().getCheckOut();
		return result;
	}
	public ArrayList getCheckedInRoomNumbers() {
		ArrayList result = new StaffWindowJDBC().getCheckedInRoomNumbers();
		return result;
	}
	
	public ArrayList getExtraServiceTable() {
		ArrayList result = new StaffWindowJDBC().getExtraServiceTable();
		return result;
	}
	public ArrayList getRBServiceTable() {
		ArrayList result = new StaffWindowJDBC().getRBServiceTable();
		return result;
	}
	public boolean addBill(StaffWindowManagement swm) {
		boolean result = new StaffWindowJDBC().addBill(swm);
		return result;
	}

}
