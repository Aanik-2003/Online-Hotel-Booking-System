package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import models.RegisterManagement;

public class RegisterJDBC {

	public boolean saveNonCorporateCustomer(RegisterManagement register) {

		boolean result = false;
		String query = "INSERT INTO table_customer (title,first_name,last_name,age,gender,email,password,phone_no,address_line1,address_line2,city,country,post_code,customer_type_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			// create a connection to the database
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root",
					"Mniakm#1");

			PreparedStatement pst = conn.prepareStatement(query);

			// set the parameter for the prepared statement
			pst.setObject(1, register.getTitle());
			pst.setString(2, register.getFirstName());
			pst.setString(3, register.getLastName());
			pst.setInt(4, register.getAge());
			pst.setObject(5, register.getGender());
			pst.setString(6, register.getEmail());
			pst.setString(7, register.getPassword());
			pst.setString(8, register.getPhoneNo());
			pst.setString(9, register.getAddressLine1());
			pst.setString(10, register.getAddressLine2());
			pst.setString(11, register.getCity());
			pst.setString(12, register.getCountry());
			pst.setString(13, register.getPostCode());
			pst.setObject(14, 2);

			pst.executeUpdate();
			pst.close();
			conn.close();

			result = true;

		} catch (Exception ex) {
			System.out.println("Error" + ex.getMessage());

		}
		return result;
	}

	public boolean saveCorporateCustomer(RegisterManagement register) {

		boolean result = false;
		String query = "INSERT INTO table_customer (title,first_name,last_name,age,gender,email,password,phone_no,address_line1,address_line2,city,country,post_code,customer_type_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			// create a connection to the database
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root",
					"Mniakm#1");
			// create a prepared statement with an SQL INSERT statement
			PreparedStatement pst = conn.prepareStatement(query);
			// set the parameter for the prepared statement
			pst.setObject(1, register.getTitle());
			pst.setString(2, register.getFirstName());
			pst.setString(3, register.getLastName());
			pst.setInt(4, register.getAge());
			pst.setObject(5, register.getGender());
			pst.setString(6, register.getEmail());
			pst.setString(7, register.getPassword());
			pst.setString(8, register.getPhoneNo());
			pst.setString(9, register.getAddressLine1());
			pst.setString(10, register.getAddressLine2());
			pst.setString(11, register.getCity());
			pst.setString(12, register.getCountry());
			pst.setString(13, register.getPostCode());
			pst.setObject(14, 1);

			pst.executeUpdate();
			pst.close();
			conn.close();

			result = true;
		} catch (Exception ex) {
			System.out.println("Error" + ex.getMessage());

		}
		return result;
	}

	public ArrayList<RegisterManagement> getNonCorporateCustomer() {

		ArrayList customers = new ArrayList<RegisterManagement>();
		String query = "SELECT * FROM table_customer";
		try {
			// create a connection to the database
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
					
			PreparedStatement pst = conn.prepareStatement(query);
			
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				RegisterManagement customer = new RegisterManagement();
				int tmpCid = rs.getInt("customer_id");
				String fname = rs.getString("first_name");
				customer.setCustomerID(tmpCid);
				customer.setFirstName(fname);
				customers.add(customer);
			}
			pst.executeUpdate();
			pst.close();
			conn.close();
		} catch (Exception ex) {
			System.out.println("Error" + ex.getMessage());

		}
		return customers;
	}

}
