package controllers;

import models.StaffLoginManagement;

public class StaffLoginController {

private StaffLoginManagement staffLogin;
	
	public StaffLoginController() {
		this.staffLogin = new StaffLoginManagement();
	}
	public StaffLoginController(StaffLoginManagement staffLogin) {
		this.staffLogin = staffLogin;
	}
	public StaffLoginManagement getUser() {
		return staffLogin;
	}
	public void setUser(StaffLoginManagement staffLogin) {
		this.staffLogin = staffLogin;
	}
	public void staffLogin() {
		this.staffLogin = new StaffLoginJDBC().staffLogin(this.staffLogin);
	}
}
