package controllers;

import java.sql.*;
import java.util.ArrayList;

import models.GuestWindowManagement;
import models.CustomerLoginManagement;
import models.RegisterManagement;
import models.StaffLoginManagement;
import models.StaffWindowManagement;


public class GuestWindowJDBC {
	
	public boolean createBookingNormalCustomer(GuestWindowManagement gwm) {
		boolean result = false;
		try {
    		
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        // insert the check-in and check-out dates into the table_booking table
	        String query1 = "INSERT INTO table_booking (checkIn_date, checkOut_date, customer_id,booking_status_id,room_type_id) VALUES (?,?,?,?,?)";
	        PreparedStatement pst1 = conn.prepareStatement(query1);
	        pst1.setDate(1, (Date) gwm.getArrivalDate());
	        pst1.setDate(2, (Date) gwm.getDepartureDate());
	        pst1.setInt(3, CustomerLoginManagement.customerId);
	        pst1.setInt(4, 3);
	        pst1.setInt(5, GuestWindowManagement.roomTypeId);
	        
	       
	        pst1.executeUpdate();
	        pst1.close();
			
			
			
			String query2 = "INSERT INTO table_creditCard_payment (creditCard_number,expiry_date,payment_method_id,cvv) VALUES(?,?,?,?)";
			// create a prepared statement 
			PreparedStatement pst2 = conn.prepareStatement(query2);	
			// set the parameter for the prepared statement
			pst2.setString(1, gwm.getCreditCard());
			pst2.setDate(2, (Date) gwm.getExpiryDate());
			pst2.setInt(3, 1);
			pst2.setString(4, gwm.getCvv());
			
			pst2.executeUpdate();
			pst2.close();
			
			conn.close();
			result = true;
			 
		}
		catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return result;
	}
	
	public boolean createBookingCorporateCustomer(GuestWindowManagement gwm) {
		boolean result = false;
		try {
    		
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        // insert the check-in and check-out dates into the table_booking table
	        String query1 = "INSERT INTO table_booking (checkIn_date, checkOut_date, customer_id,booking_status_id,room_type_id) VALUES (?,?,?,?,?)";
	        PreparedStatement pst1 = conn.prepareStatement(query1);
	        pst1.setDate(1, (Date) gwm.getArrivalDate());
	        pst1.setDate(2, (Date) gwm.getDepartureDate());
	        pst1.setInt(3, CustomerLoginManagement.customerId);
	        pst1.setInt(4, 3);
	        pst1.setInt(5, GuestWindowManagement.roomTypeId);
	       
	        pst1.executeUpdate();
	        pst1.close();
			
			String query3 = "INSERT INTO table_creditCard_payment (creditCard_number,expiry_date,payment_method_id,cvv) VALUES(?,?,?,?)";
			// create a prepared statement 
			PreparedStatement pst3 = conn.prepareStatement(query3);	
			// set the parameter for the prepared statement
			pst3.setString(1, gwm.getCreditCard());
			pst3.setDate(2, (Date) gwm.getExpiryDate());
			pst3.setInt(3, 1);
			pst3.setString(4, gwm.getCvv());
			
			pst3.executeUpdate();
			pst3.close();
			
			conn.close();
			result = true;
			 
		}
		catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return result;
	}
	
	public ArrayList<GuestWindowManagement> getPendingBooking() {
		ArrayList customers = new ArrayList<GuestWindowManagement>();
		String query = "SELECT \r\n"
				+ "    CONCAT(c.first_name, ' ', c.last_name) AS full_name,\r\n"
				+ "    b.checkIn_date,\r\n"
				+ "    b.checkOut_date,\r\n"
				+ "    rt.room_type_name,\r\n"
				+ "    SUM(rt.price_per_day * DATEDIFF(b.checkOut_date, b.checkIn_date)) AS room_price,\r\n"
				+ "    bs.booking_status_name\r\n"
				+ "FROM assignment1.table_booking b\r\n"
				+ "INNER JOIN table_customer c ON c.customer_id = b.customer_id\r\n"
				+ "INNER JOIN table_booking_status bs ON bs.booking_status_id = b.booking_status_id\r\n"
				+ "INNER JOIN table_room_type rt ON b.room_type_id = rt.room_type_id\r\n"
				+ "WHERE c.customer_id=? and bs.booking_status_name = 'Pending'\r\n"
				+ "GROUP BY b.booking_id;";
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setInt(1, CustomerLoginManagement.customerId);
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				GuestWindowManagement gm = new GuestWindowManagement();
				
				String fname = rs.getString("full_name");
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");
				int roomPrice = rs.getInt("room_price");
				String bookingStatus = rs.getString("booking_status_name");


				gm.setFullName(fname);
				gm.setArrivalDate(arrDate);
				gm.setDepartureDate(depDate);
				gm.setRoomType(roomType);
				gm.setRoomPrice(roomPrice);
				gm.setBookingStatus(bookingStatus);
				
				customers.add(gm);
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}
	
	public ArrayList<GuestWindowManagement> getViewBooking() {
		ArrayList customers = new ArrayList<GuestWindowManagement>();
		String query = "SELECT \r\n"
				+ "    CONCAT(c.first_name, ' ', c.last_name) AS full_name,\r\n"
				+ "    b.booking_id,\r\n"
				+ "    b.checkIn_date,\r\n"
				+ "    b.checkOut_date,\r\n"
				+ "    rt.room_type_name,\r\n"
				+ "    SUM(rt.price_per_day * DATEDIFF(b.checkOut_date, b.checkIn_date)) AS room_price,\r\n"
				+ "    bs.booking_status_name\r\n"
				+ "FROM assignment1.table_booking b\r\n"
				+ "INNER JOIN table_customer c ON c.customer_id = b.customer_id\r\n"
				+ "INNER JOIN table_booking_status bs ON bs.booking_status_id = b.booking_status_id\r\n"
				+ "INNER JOIN table_room_type rt ON b.room_type_id = rt.room_type_id\r\n"
				+ "WHERE c.customer_id = ?\r\n"
				+ "GROUP BY b.booking_id;";
		try {
			 // create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        
	        PreparedStatement pst = conn.prepareStatement(query);
	        pst.setInt(1, CustomerLoginManagement.customerId);
	        
	        
	        ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				
				GuestWindowManagement gm = new GuestWindowManagement();
				
				
				String fname = rs.getString("full_name");
				int bId = rs.getInt("booking_id");
				Date arrDate = rs.getDate("checkIn_date");
				Date depDate = rs.getDate("checkOut_date");
				String roomType = rs.getString("room_type_name");
				int roomPrice = rs.getInt("room_price");
				String bookingStatus = rs.getString("booking_status_name");

				gm.setFullName(fname);
				gm.setBookingId(bId);
				gm.setArrivalDate(arrDate);
				gm.setDepartureDate(depDate);
				gm.setRoomType(roomType);
				gm.setRoomPrice(roomPrice);
				gm.setBookingStatus(bookingStatus);
				
				customers.add(gm);
				
				
				
				
			}
			pst.close();
			conn.close();
		
		}catch(Exception ex) {
			System.out.println("Error: "+ex.getMessage());
		}
		return customers;
	}

	public boolean updateBooking(GuestWindowManagement gwm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query1 = "update table_booking set checkIn_date=?,checkOut_date=?,room_type_id=? where customer_id=? and booking_id=?";
	        PreparedStatement pst1 = conn.prepareStatement(query1);
	        pst1.setDate(1, (Date) gwm.getArrivalDate());
	        pst1.setDate(2, (Date) gwm.getDepartureDate());
	        pst1.setInt(3, GuestWindowManagement.roomTypeId);
	        pst1.setInt(4, CustomerLoginManagement.customerId);
	        pst1.setInt(5, gwm.getBookingId());
	        
	        pst1.executeUpdate();
	        pst1.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
	
	public boolean deleteBooking(GuestWindowManagement gwm) {
		
		boolean result = false;
		try {
			// create a connection to the database
	        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/assignment1", "root","Mniakm#1");
	        String query = "delete from table_booking where customer_id = ? and booking_id = ?;";
	        PreparedStatement pst = conn.prepareStatement(query);
	        
	        pst.setInt(1, CustomerLoginManagement.customerId);
	        pst.setInt(2, gwm.getBookingId());
	        
	        pst.executeUpdate();
	        pst.close();
	        conn.close();
	        
	        result=true;
		}catch(Exception ex) {
			System.out.println("Error:"+ex.getMessage());
		}
		return result;
	}
}
