package views;

import javax.swing.*;

import controllers.RegisterController;
import models.RegisterManagement;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class RegisterWindow extends JFrame implements ActionListener{
//	instance variables
	JLabel imageLbl, customerTypeLbl, txt1Lbl, titleLbl, firstNameLbl, lastNameLbl, ageLbl, genderLbl, emailLbl, passLbl, confirmPassLbl, phoneLbl, addLine1Lbl, addLine2Lbl, cityLbl, countryLbl, postCodeLbl;
	JTextField firstNameFld, lastNameFld, ageFld, emailFld, passFld, confirmPassFld, phoneFld, addLine1Fld, addLine2Fld, cityFld, countryFld, postCodeFld;
	ImageIcon i;
	JComboBox<String> customerTypeComboBox, titleTypeComboBox, genderTypeComboBox;
	JButton submitBtn, closeBtn;
	
	public RegisterWindow() {
		setTitle("Registration Window"); // title of window
		setResizable(true);	// can change the size of window
		setLayout(null);  // manual set of layout
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();  // create an object 
	    setSize(screenSize.width, screenSize.height); // Set the size of the frame to be the size of the screen
		
		i= new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\icons\\dark.jpg");  // creates an object and adding image
		imageLbl= new JLabel(i);
		imageLbl.setBounds(0,0,screenSize.width,screenSize.height);	// setting size and location of image
		
		txt1Lbl = new JLabel("Luton Hotel Registration Form");
		txt1Lbl.setBounds(400,0,900,150);
		txt1Lbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		txt1Lbl.setFont(new Font("serif",Font.BOLD, 60));	// setting font of text1
		
		customerTypeLbl = new JLabel("Type");
		customerTypeLbl.setBounds(400,180,100,40);
		customerTypeLbl.setForeground(Color.WHITE);
		customerTypeLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		String[] custType = {"Corporate", "Non-Corporate"};		
		customerTypeComboBox = new JComboBox <>(custType);
		customerTypeComboBox.setSelectedIndex(-1);
		customerTypeComboBox.setBounds(540,190,100,20);
		
		
		titleLbl = new JLabel("Title");
		titleLbl.setBounds(900,180,100,40);
		titleLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		titleLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		String[] titleType = {"Mr.", "Mrs."};
		titleTypeComboBox = new JComboBox <>(titleType);
		titleTypeComboBox.setSelectedIndex(-1);
		titleTypeComboBox.setBounds(1040,190,100,20);
		
		firstNameLbl = new JLabel("First Name");
		firstNameLbl.setBounds(400,220,100,40);
		firstNameLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		firstNameLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		firstNameFld = new JTextField();
		firstNameFld.setBounds(540,230,200,20);
		
		lastNameLbl = new JLabel("Last Name");
		lastNameLbl.setBounds(900,220,100,40);
		lastNameLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		lastNameLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		lastNameFld = new JTextField();
		lastNameFld.setBounds(1040,230,200,20);
		
		ageLbl = new JLabel("Age");
		ageLbl.setBounds(400,260,100,40);
		ageLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		ageLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		ageFld = new JTextField();
		ageFld.setBounds(540,270,200,20);
		
		genderLbl = new JLabel("Gender");
		genderLbl.setBounds(900,260,100,40);
		genderLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		genderLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		String[] genType = {"Male", "Female", "Others"};
		genderTypeComboBox = new JComboBox<>(genType);
		genderTypeComboBox.setSelectedIndex(-1);
		genderTypeComboBox.setBounds(1040,270,100,20);
		
		phoneLbl = new JLabel("Phone Number");
		phoneLbl.setBounds(400,300,100,40);
		phoneLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		phoneLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		phoneFld = new JTextField();
		phoneFld.setBounds(540,310,200,20);
		
		addLine1Lbl = new JLabel("Address 1");
		addLine1Lbl.setBounds(900,300,100,40);
		addLine1Lbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		addLine1Lbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		addLine1Fld = new JTextField();
		addLine1Fld.setBounds(1040,310,200,20);
		
		addLine2Lbl = new JLabel("Address 2");
		addLine2Lbl.setBounds(400,340,100,40);
		addLine2Lbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		addLine2Lbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		addLine2Fld = new JTextField();
		addLine2Fld.setBounds(540,350,200,20);
		
		postCodeLbl = new JLabel("Post Code");
		postCodeLbl.setBounds(900,340,100,40);
		postCodeLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		postCodeLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		postCodeFld = new JTextField();
		postCodeFld.setBounds(1040,350,200,20);
		
		cityLbl = new JLabel("City");
		cityLbl.setBounds(400,380,100,40);
		cityLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		cityLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		cityFld = new JTextField();
		cityFld.setBounds(540,390,200,20);
		
		countryLbl = new JLabel("Country");
		countryLbl.setBounds(900,380,100,40);
		countryLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		countryLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		countryFld = new JTextField();
		countryFld.setBounds(1040,390,200,20);
		
		emailLbl = new JLabel("Email");
		emailLbl.setBounds(400,420,100,40);
		emailLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		emailLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		emailFld = new JTextField();
		emailFld.setBounds(540,430,200,20);
		
		passLbl = new JLabel("Password");
		passLbl.setBounds(900,420,100,40);
		passLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		passLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		passFld = new JTextField();
		passFld.setBounds(1040,430,200,20);
		
		confirmPassLbl = new JLabel("Confirm Password");
		confirmPassLbl.setBounds(400,460,200,40);
		confirmPassLbl.setForeground(Color.WHITE);	// setting foreground color of text1 
		confirmPassLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		
		confirmPassFld = new JTextField();
		confirmPassFld.setBounds(540,470,200,20);
		
		submitBtn = new JButton("Submit");
		submitBtn.setBounds(400,580,80,30);
		submitBtn.setBackground(Color.WHITE);
		submitBtn.setForeground(Color.BLACK);	// setting foreground color of text1 
		submitBtn.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		submitBtn.addActionListener(this);
		
		closeBtn = new JButton("Close");
		closeBtn.setBounds(490,580,80,30);
		closeBtn.setBackground(Color.WHITE);
		closeBtn.setForeground(Color.BLACK);	// setting foreground color of text1 
		closeBtn.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
		closeBtn.addActionListener(this);
		
		imageLbl.add(customerTypeLbl);
		imageLbl.add(customerTypeComboBox);
		imageLbl.add(txt1Lbl);
		imageLbl.add(titleLbl);
		imageLbl.add(titleTypeComboBox);
		imageLbl.add(firstNameLbl);
		imageLbl.add(firstNameFld);
		imageLbl.add(lastNameLbl);
		imageLbl.add(lastNameFld);
		imageLbl.add(ageLbl);
		imageLbl.add(ageFld);
		imageLbl.add(genderLbl);
		imageLbl.add(genderTypeComboBox);
		imageLbl.add(phoneLbl);
		imageLbl.add(phoneFld);
		imageLbl.add(addLine1Lbl);
		imageLbl.add(addLine1Fld);
		imageLbl.add(addLine2Lbl);
		imageLbl.add(addLine2Fld);
		imageLbl.add(postCodeLbl);
		imageLbl.add(postCodeFld);
		imageLbl.add(cityLbl);
		imageLbl.add(cityFld);
		imageLbl.add(countryLbl);
		imageLbl.add(countryFld);
		imageLbl.add(emailLbl);
		imageLbl.add(emailFld);
		imageLbl.add(passLbl);
		imageLbl.add(passFld);
		imageLbl.add(confirmPassLbl);
		imageLbl.add(confirmPassFld);
		imageLbl.add(submitBtn);
		imageLbl.add(closeBtn);
		
		
		
		add(imageLbl);
		
		setVisible(true);

	
}
	@Override
	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==submitBtn) {

			if(customerTypeComboBox.getSelectedItem()=="Non-Corporate") {
					
				RegisterManagement register = new RegisterManagement(
				customerTypeComboBox.getSelectedItem(),titleTypeComboBox.getSelectedItem(),firstNameFld.getText(), lastNameFld.getText(), 
				Integer.parseInt(ageFld.getText()),genderTypeComboBox.getSelectedItem(), emailFld.getText(), 
				passFld.getText(), phoneFld.getText(),addLine1Fld.getText(),addLine2Fld.getText(),cityFld.getText(),
				countryFld.getText(),postCodeFld.getText());
				boolean result = new RegisterController().saveNonCorporateCustomer(register);
					
				if(result==true) {
					//Save message
					JOptionPane.showMessageDialog(this, "Registration Successful");
				}
				else {
					//error message
					JOptionPane.showMessageDialog(this, "Error to save record");
					}
					
			}
			else {
					
				RegisterManagement register = new RegisterManagement(
				customerTypeComboBox.getSelectedItem(),titleTypeComboBox.getSelectedItem(),firstNameFld.getText(), lastNameFld.getText(), 
				Integer.parseInt(ageFld.getText()),genderTypeComboBox.getSelectedItem(), emailFld.getText(), 
				passFld.getText(), phoneFld.getText(),addLine1Fld.getText(),addLine2Fld.getText(),cityFld.getText(),
				countryFld.getText(),postCodeFld.getText());
	
				boolean result = new RegisterController().saveCorporateCustomer(register);
				if(result==true) {
					//Save message
					JOptionPane.showMessageDialog(this, "Registration Successful");
				}
				else {
					//error message
					JOptionPane.showMessageDialog(this, "Error to save record");
				}					
			}
		}
			
		else if(ae.getSource()==closeBtn) {
			this.dispose();
			MainWindow mw = new MainWindow();
			mw.setVisible(true);
		}

	}
	public static void main(String[] args) {
		new RegisterWindow();
	}
}
