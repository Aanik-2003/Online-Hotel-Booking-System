package views;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import controllers.GuestWindowController;
import controllers.StaffWindowController;
import controllers.StaffWindowJDBC;
import models.GuestWindowManagement;
import models.StaffWindowManagement;

import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class StaffWindow extends JFrame implements ActionListener {
    
    private JDesktopPane desktopPane;  // added desktop pane
    private JMenuBar menuBar;
    private JMenu bookMenu, extServiceMenu, rbMenu, billMenu, exitMenu;
    private JMenuItem view,checkIn, checkOut, add, addRB,create, close;
    private ImageIcon i;
    private JLabel imageLbl;
    private JInternalFrame viewFrame,viewBookingFrame,checkInFrame, viewCheckInFrame, checkOutFrame, viewCheckOutFrame, addServiceFrame, rbFrame,createBillFrame;
    DefaultTableModel cModel,outModel;
    JTable confirmedTable,outTable;
    
    public StaffWindow() {
        
        desktopPane = new JDesktopPane();  // create the desktop pane
        setContentPane(desktopPane);  // set the desktop pane as the content pane
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setResizable(true);
        setTitle("Staff Window");
        
        i = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\icons\\Lobby - Reception Area.jpg");
        imageLbl = new JLabel(i);
        imageLbl.setBounds(0, 0, screenSize.width, screenSize.height);
        desktopPane.add(imageLbl);  // add the label to the desktop pane
        
        menuBar = new JMenuBar();
        menuBar.setBackground(Color.black);
        
        bookMenu = new JMenu("Book");
        bookMenu.setForeground(Color.white);
        
        extServiceMenu = new JMenu("Ext.Services");
        extServiceMenu.setForeground(Color.white);
        
        rbMenu = new JMenu("Restaurant & Bar");
        rbMenu.setForeground(Color.white);
        
        billMenu = new JMenu("Bill");
        billMenu.setForeground(Color.white);
        
        exitMenu = new JMenu("Exit");
        exitMenu.setForeground(Color.white);
        
        view = new JMenuItem("View");
        view.addActionListener(this);

        checkIn = new JMenuItem("Check-In");
        checkIn.addActionListener(this);
        
        checkOut = new JMenuItem("Check-Out");
        checkOut.addActionListener(this);
        
        add = new JMenuItem("Add");
        add.addActionListener(this);
        
        addRB = new JMenuItem("Add");
        addRB.addActionListener(this);
       
        create = new JMenuItem("Create");
        create.addActionListener(this);
        
        close = new JMenuItem("Close");
        close.addActionListener(this);
        
        bookMenu.add(view);
        bookMenu.add(checkIn);
        bookMenu.add(checkOut);
        extServiceMenu.add(add);
        rbMenu.add(addRB);
        billMenu.add(create);
        exitMenu.add(close);
        
        menuBar.add(bookMenu);
        menuBar.add(extServiceMenu);
        menuBar.add(rbMenu);
        menuBar.add(billMenu);
        menuBar.add(exitMenu);
        setJMenuBar(menuBar);
        
        viewFrame = new JInternalFrame("Booking Form",false,true,false,false);
        initFrame1(viewFrame);
        
        viewBookingFrame = new JInternalFrame("Booking Confirmed Lists",false,true,false,false);
        initFrame2(viewBookingFrame);
        
        checkInFrame = new JInternalFrame("Today's Checked-In Form",false,true,false,false);
        initFrame3(checkInFrame);
        
        viewCheckInFrame = new JInternalFrame("Customers Checked-In Lists",false,true,false,false);
        initFrame4(viewCheckInFrame);
        
        checkOutFrame = new JInternalFrame("Today's Checked-Out Form",false,true,false,false);
        initFrame5(checkOutFrame);
        
        viewCheckOutFrame = new JInternalFrame("Customers Checked-Out Lists",false,true,false,false);
        initFrame6(viewCheckOutFrame);
        
        addServiceFrame = new JInternalFrame("Extra Services Form",false,true,false,false);
        initFrame7(addServiceFrame);
        
        rbFrame = new JInternalFrame("Restaurant and Bar",false,true,false,false);
        initFrame8(rbFrame);
        
        createBillFrame = new JInternalFrame("Online Payment Form",false,true,false,false);
        initFrame9(createBillFrame);
        
        setVisible(true);
    }
   
    private void initFrame1 (JInternalFrame viewFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,cusIdLbl,bookingLbl,arrivalDateLbl, departureDateLbl,rTypeLbl,rNumLbl;
    	JTextField cusIdFld,bookingFld;
    	JDateChooser arrDate,depDate;
    	JComboBox <String>rTypeComboBox;
    	JComboBox <String>rNumComboBox;
    	JButton confirmBtn,deleteBtn,viewBtn,closeBtn;
    	Calendar arrCalendar,depCalendar;
    	DefaultTableModel pModel;
    	JTable pendingTable;
    	JScrollPane scrollPane;
    	
    	viewFrame.setSize(700,500);
    	viewFrame.setLocation(400,200);
    	viewFrame.setResizable(false);
    	viewFrame.setLayout(null);
    	viewFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	viewFrame.setTitle("Booking Form");
	    
	    titleLbl = new JLabel("Booking Confirmation Form");
	    titleLbl.setBounds(50,0,400,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(50, 50, 600, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    String[] columnNames = {"Customer Id","Booking Id","Check-InDate","Check-OutDate","Room Type","Booking Status"};
		pModel = new DefaultTableModel(columnNames, 0);
		pendingTable = new JTable(pModel);
		pendingTable.setFont(new Font("serif",Font.BOLD, 12));		
		
		scrollPane = new JScrollPane(pendingTable);
		scrollPane.setBounds(5, 235, 590, 164);
		
	    cusIdLbl = new JLabel("Customer ID");
	    cusIdLbl.setBounds(10,10,100,20);
	    cusIdLbl.setForeground(Color.black);
	    cusIdLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    cusIdFld = new JTextField();
	    cusIdFld.setBounds(120,10,150,25);
	    
	    bookingLbl = new JLabel("Booking Id");
	    bookingLbl.setBounds(320,10,150,20);
	    bookingLbl.setForeground(Color.black);
	    bookingLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    bookingFld = new JTextField();
	    bookingFld.setBounds(440,10,150,25);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,60,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,60,150,25);
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(320,60,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();	    
	    depDate.setBounds(440,60,150,25);
		
	    rTypeLbl = new JLabel("Room Type");
	    rTypeLbl.setBounds(10,110,100,20);
	    rTypeLbl.setForeground(Color.black);
	    rTypeLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	  
	    String rType[] = {"Single", "Double", "Twin"};
	    rTypeComboBox = new JComboBox <>(rType);
	    rTypeComboBox.setSelectedIndex(-1);
	    rTypeComboBox.setBounds(120, 110, 150, 25);
	    
	    
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(320,110,100,20);
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] rNum = {};
	    rNumComboBox = new JComboBox<>(rNum);
	    rNumComboBox.setSelectedIndex(-1);
	    rNumComboBox.setBounds(440, 110, 150, 25);
	    
		
		confirmBtn = new JButton("CONFIRM");
		confirmBtn.setBounds(20,180,120,30);
		confirmBtn.setFont(new Font("serif",Font.BOLD, 17));
		confirmBtn.setForeground(Color.black);
		confirmBtn.setBackground(Color.green);
		
		
		
		confirmBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==confirmBtn) {
		    	  
		    		StaffWindowManagement swm = new StaffWindowManagement(Integer.parseInt(cusIdFld.getText()),Integer.parseInt(bookingFld.getText()),
		    				Integer.parseInt(rNumComboBox.getSelectedItem().toString()));
		    		
		    		boolean result = new StaffWindowController().confirmBooking(swm);
		    		if(result==true) {
		    		
		    			JOptionPane.showMessageDialog(viewFrame, "Confirmation Successful");
		    			
		    			cusIdFld.setText("");
		    			bookingFld.setText("");
		    			arrDate.setDate(null);
		    			depDate.setDate(null);
		    			rTypeComboBox.setSelectedIndex(-1);
		    			rNumComboBox.setSelectedIndex(-1);
		    			
		    			pModel.fireTableDataChanged();
		    			new StaffWindowController().getPendingBooking();
		    			
	
		    		}else {
		    			JOptionPane.showMessageDialog(viewFrame, "Fail to Confirm Booking");
		    			}
	    	        }	    			    	
		    	}
		});

		deleteBtn = new JButton("DELETE");
		deleteBtn.setBounds(170,180,120,30);
		deleteBtn.setFont(new Font("serif",Font.BOLD, 17));
		deleteBtn.setForeground(Color.black);
		deleteBtn.setBackground(Color.red);
		

		deleteBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the close button is clicked
		    	StaffWindowManagement swm = new StaffWindowManagement(Integer.parseInt(cusIdFld.getText()),Integer.parseInt(bookingFld.getText()));
	    		boolean result = new StaffWindowController().deleteBooking(swm);
	    		if(result==true) {
	    		
	    			JOptionPane.showMessageDialog(viewFrame, "Booking Deleted Successfully");
	    			arrDate.setDate(null);
	    			depDate.setDate(null);
	    			rTypeComboBox.setSelectedIndex(-1);
	    			rNumComboBox.setSelectedIndex(-1);
	    			bookingFld.setText("");
	    			cusIdFld.setText("");
	    			
	    			pModel.fireTableDataChanged();
	    			new GuestWindowController().getViewBooking();
	    			
	    		}else {
	    			JOptionPane.showMessageDialog(viewFrame, "Fail to Delete Booking");
	    		}
		    }
		});
		
		viewBtn = new JButton("VIEW");
		viewBtn.setBounds(330,180,110,30);
		viewBtn.setFont(new Font("serif",Font.BOLD, 17));
		viewBtn.setForeground(Color.black);
		viewBtn.setBackground(Color.blue);
		
		
		
		viewBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {

		    	desktopPane.add(viewBookingFrame, JLayeredPane.DEFAULT_LAYER);
		    	viewBookingFrame.setVisible(true);
		    	
		    	// notify the table that the data has changed
		        cModel.fireTableDataChanged();
		    	new StaffWindowController().getConfirmedBooking();
		        
		    }
		});
		
		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(470,180,110,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		
		closeBtn.addActionListener(new ActionListener(){
			 public void actionPerformed(ActionEvent ae) {
			     viewFrame.setVisible(false);   
			    }
			});
		
		// clear existing data from the model
		pModel.setRowCount(0);
         
        // populate the table with the updated data
        ArrayList<StaffWindowManagement> customers = new StaffWindowController().getPendingBooking();

        for (int i = 0; i < customers.size(); i++) {
            StaffWindowManagement customer = customers.get(i);
            String[] rowData = {Integer.toString(customer.getCustomerId()),Integer.toString(customer.getBookingId()),customer.getArrivalDate().toString(), 
            					customer.getDepartureDate().toString(),customer.getRoomType().toString(), customer.getBookingStatus()};
            pModel.addRow(rowData);
        }

        // notify the table that the data has changed
        pModel.fireTableDataChanged();
		
     // Add a ListSelectionListener to the table
        pendingTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
     		    public void valueChanged(ListSelectionEvent event) {
     		        if (!event.getValueIsAdjusting()) {
     		        	// Get the selected row index
     		            int rowIndex = pendingTable.getSelectedRow();
     		            if (rowIndex >= 0) { // If a row is selected
     		            	String customerId = (String) pendingTable.getValueAt(rowIndex,0);
     		            	String bookingId = (String) pendingTable.getValueAt(rowIndex, 1);
     		            	String arrivalDateStr = (String) pendingTable.getValueAt(rowIndex, 2);
     		            	String departureDateStr = (String) pendingTable.getValueAt(rowIndex, 3);

     		            	DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Replace the format string with your own date format

     		            	Date arrivalDate = null;
     		            	Date departureDate = null;

     		            	try {
     		            	    arrivalDate = df.parse(arrivalDateStr);
     		            	    departureDate = df.parse(departureDateStr);
     		            	} catch (ParseException e) {
     		            	    e.printStackTrace();
     		            	}

     		            	String roomType = (String) pendingTable.getValueAt(rowIndex, 4);
     		                // Set the values of the fields to the selected row values
     		            	cusIdFld.setText(customerId);
     		            	bookingFld.setText(bookingId);
     		            	arrDate.setDate(arrivalDate);
     		                depDate.setDate(departureDate);		                 		                 
     		                rTypeComboBox.setSelectedItem(roomType);
     		               if (roomType.equals("Single")) {
     		                   StaffWindowManagement.setRoomTypeId(1);
     		                    
     		                } else if (roomType.equals("Twin")) {
     		                	StaffWindowManagement.setRoomTypeId(3);
     		                    
     		                } else if (roomType.equals("Double")) {
     		                	StaffWindowManagement.setRoomTypeId(2);
     		                }
     		              ArrayList<StaffWindowManagement> roomNumbers = new StaffWindowController().checkRoom();
     		              rNumComboBox.removeAllItems(); // clear existing items
     		              for (int i = 0; i < roomNumbers.size(); i++) {
     		            	  StaffWindowManagement roomNumber = roomNumbers.get(i);
     		            	  rNumComboBox.addItem(String.valueOf(roomNumber.getRoomNumber())); // add new items
     		             	}
     		            }   		               
     		        }
     		    }
     		});
                 
		
        
	    panel.add(cusIdLbl);
	    panel.add(cusIdFld);
	    panel.add(bookingLbl);
	    panel.add(bookingFld);
	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(rTypeLbl);
	    panel.add(rTypeComboBox);	
	    panel.add(rNumLbl);
	    panel.add(rNumComboBox);
	    panel.add(confirmBtn);
	    panel.add(deleteBtn);
	    panel.add(viewBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    
	    
	    viewFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    viewFrame.getContentPane().add(panel);
	    
    }
    private void initFrame2(JInternalFrame viewBookingFrame) {
    	viewBookingFrame.setSize(700,500);
    	viewBookingFrame.setLocation(400,270);
    	viewBookingFrame.setResizable(false);
    	viewBookingFrame.setLayout(null);
    	viewBookingFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	viewBookingFrame.setTitle("Booking Confirmed Lists");
    	
    	String[] columnNames = {"Customer Id","Full Name","Check-In Date","Check-Out Date","Room Type","Room No","Booking Status","Approved By"};
		cModel = new DefaultTableModel(columnNames, 0);
		confirmedTable = new JTable(cModel);
		confirmedTable.setFont(new Font("serif",Font.BOLD, 12));
		
		
		JScrollPane scrollPane = new JScrollPane(confirmedTable);
		scrollPane.setBounds(0,10,690,496);
		
		// clear existing data from the model
		cModel.setRowCount(0);

        // populate the table with the updated data
        ArrayList<StaffWindowManagement> confirmedBooking = new StaffWindowController().getConfirmedBooking();

        for (int i = 0; i < confirmedBooking.size(); i++) {
        	StaffWindowManagement cb = confirmedBooking.get(i);
        	String[] rowData = { Integer.toString(cb.getCustomerId()),cb.getCustomerName(), cb.getArrivalDate().toString(), cb.getDepartureDate().toString(),
        			cb.getRoomType().toString(), String.valueOf(cb.getRoomNumber()), cb.getBookingStatus(),cb.getStaffName()};
        	cModel.addRow(rowData);
        }

        // notify the table that the data has changed
        cModel.fireTableDataChanged();
			
		
    	
		viewBookingFrame.add(scrollPane);
		
    }
    private void initFrame3(JInternalFrame checkInFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,cusIdLbl,bookingLbl,arrivalDateLbl,departureDateLbl,rTypeLbl,rNumLbl;
    	JTextField cusIdFld,bookingFld;
    	JDateChooser arrDate,depDate;
    	JComboBox<String> rTypeComboBox;
    	JComboBox<String> rNumComboBox;
    	JButton checkInBtn,closeBtn,viewBtn;
    	
    	checkInFrame.setSize(700,500);
    	checkInFrame.setLocation(400,200);
    	checkInFrame.setResizable(false);
    	checkInFrame.setLayout(null);
    	checkInFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	checkInFrame.setTitle("Checked-In Form");
	    
	    titleLbl = new JLabel("Today's Check-In Form");
	    titleLbl.setBounds(50,0,400,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(50, 50, 600, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    cusIdLbl = new JLabel("Customer ID");
	    cusIdLbl.setBounds(10,10,100,20);
	    cusIdLbl.setForeground(Color.black);
	    cusIdLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    cusIdFld = new JTextField();
	    cusIdFld.setBounds(120,10,150,25);
	    
	    bookingLbl = new JLabel("Booking Id");
	    bookingLbl.setBounds(320,10,150,20);
	    bookingLbl.setForeground(Color.black);
	    bookingLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    bookingFld = new JTextField();
	    bookingFld.setBounds(440,10,150,25);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,60,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,60,150,25);
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(320,60,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();
	    depDate.setBounds(440,60,150,25);
		
	    rTypeLbl = new JLabel("Room Type");
	    rTypeLbl.setBounds(10,110,100,20);
	    rTypeLbl.setForeground(Color.black);
	    rTypeLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	   
	    String rType[] = {"Single", "Double", "Twin"};
	    rTypeComboBox = new JComboBox <>(rType);
	    rTypeComboBox.setSelectedIndex(-1);
	    rTypeComboBox.setBounds(120, 110, 150, 25);
	    
	    
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(320,110,100,20);
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] rNum = {};
	    rNumComboBox = new JComboBox<>(rNum);
	    rNumComboBox.setSelectedIndex(-1);
	    rNumComboBox.setBounds(440, 110, 150, 25);
	    
		
	    checkInBtn = new JButton("CHECK-IN");
	    checkInBtn.setBounds(110,180,120,30);
	    checkInBtn.setFont(new Font("serif",Font.BOLD, 17));
	    checkInBtn.setForeground(Color.black);
	    checkInBtn.setBackground(Color.green);
		
	    checkInBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==checkInBtn) {
		    		StaffWindowManagement swm = new StaffWindowManagement(Integer.parseInt(cusIdFld.getText()),Integer.parseInt(bookingFld.getText()),
		    				Integer.parseInt(rNumComboBox.getSelectedItem().toString()));
		    		
		    		boolean result = new StaffWindowController().confirmCheckIn(swm);
		    		if(result==true) {
		    		
		    			JOptionPane.showMessageDialog(checkInFrame, "Checked-In Successful");
		    			
		    			new StaffWindowController().confirmCheckIn(swm);
		    			cusIdFld.setText("");
		    			bookingFld.setText("");
		    			arrDate.setDate(null);
		    			depDate.setDate(null);
		    			rTypeComboBox.setSelectedIndex(-1);
		    			rNumComboBox.setSelectedIndex(-1);
		    			
		    			
	
		    		}else {
		    			JOptionPane.showMessageDialog(checkInFrame, "Fail to Checked-In");
		    			}
		    		
		    	}
		    }
		});

		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(280,180,100,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		

		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the close button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		checkInFrame.setVisible(false);
		    	}
		    }
		});
		
		viewBtn = new JButton("VIEW");
		viewBtn.setBounds(450,180,100,30);
		viewBtn.setFont(new Font("serif",Font.BOLD, 17));
		viewBtn.setForeground(Color.black);
		viewBtn.setBackground(Color.blue);
		
		
		
		viewBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
//		        to do
		    	desktopPane.add(viewCheckInFrame, JLayeredPane.DEFAULT_LAYER);
		    	viewCheckInFrame.setVisible(true);
		    }
		});
		
		
		String[] columnNames = {"Customer Id","Booking Id","Check-In Date","Check-Out Date","Room Type","Room No","Room Status"};
		DefaultTableModel inModel = new DefaultTableModel(columnNames, 0);
		JTable reservedTable = new JTable(inModel);
		reservedTable.setFont(new Font("serif",Font.BOLD, 12));
		
		
		JScrollPane scrollPane = new JScrollPane(reservedTable);
		scrollPane.setBounds(5, 235, 590, 164);
		
		// clear existing data from the model
		inModel.setRowCount(0);
		         
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> customers = new StaffWindowController().getReservedTable();
		
		for (int i = 0; i < customers.size(); i++) {
			StaffWindowManagement customer = customers.get(i);
			String[] rowData = {Integer.toString(customer.getCustomerId()),Integer.toString(customer.getBookingId()),customer.getArrivalDate().toString(), 
			customer.getDepartureDate().toString(),customer.getRoomType().toString(),String.valueOf(customer.getRoomNumber()),customer.getRoomStatus()};
			inModel.addRow(rowData);
		}

		// notify the table that the data has changed
		inModel.fireTableDataChanged();
		new StaffWindowController().getReservedTable();
				
		// Add a ListSelectionListener to the table
		reservedTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		public void valueChanged(ListSelectionEvent event) {
		if (!event.getValueIsAdjusting()) {
			// Get the selected row index
			int rowIndex = reservedTable.getSelectedRow();
			if (rowIndex >= 0) { // If a row is selected
				String customerId = (String) reservedTable.getValueAt(rowIndex,0);
				String bookingId = (String) reservedTable.getValueAt(rowIndex, 1);
				String arrivalDateStr = (String) reservedTable.getValueAt(rowIndex, 2);
				String departureDateStr = (String) reservedTable.getValueAt(rowIndex, 3);
				
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Replace the format string with your own date format
				
				Date arrivalDate = null;
				Date departureDate = null;
				
				try {
					arrivalDate = df.parse(arrivalDateStr);
					departureDate = df.parse(departureDateStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				String roomType = (String) reservedTable.getValueAt(rowIndex, 4);
				String roomNum = (String) reservedTable.getValueAt(rowIndex, 5);
				
				
				// Set the values of the fields to the selected row values
				cusIdFld.setText(customerId);
				bookingFld.setText(bookingId);
				arrDate.setDate(arrivalDate);
				depDate.setDate(departureDate);		                 		                 
				rTypeComboBox.setSelectedItem(roomType);
	            rNumComboBox.removeAllItems(); // clear existing items 
	            rNumComboBox.addItem(roomNum); // add new items
	             	
				
			}   		               
		}
		}
		});		

		
		
        
	    panel.add(cusIdLbl);
	    panel.add(cusIdFld);
	    panel.add(bookingLbl);
	    panel.add(bookingFld);
	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(rTypeLbl);
	    panel.add(rTypeComboBox);
	    panel.add(rNumLbl);
	    panel.add(rNumComboBox);
	    panel.add(checkInBtn);
	    panel.add(closeBtn);
	    panel.add(viewBtn);
	    panel.add(scrollPane);
	    
	    
	    checkInFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    checkInFrame.getContentPane().add(panel);
	    
    }
    
    private void initFrame4(JInternalFrame viewCheckInFrame) {
    	viewCheckInFrame.setSize(700,500);
    	viewCheckInFrame.setLocation(400,270);
    	viewCheckInFrame.setResizable(false);
    	viewCheckInFrame.setLayout(null);
    	viewCheckInFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	viewCheckInFrame.setTitle("Customer Checked-In List");
    	
    	String[] columnNames = {"Full Name","Check-In Date","Check-Out Date","Room Type","Room No","Booking Status"};
		DefaultTableModel model = new DefaultTableModel(columnNames, 0);
		JTable inTable = new JTable(model);
		inTable.setFont(new Font("serif",Font.BOLD, 12));
		
		
		JScrollPane scrollPane = new JScrollPane(inTable);
		scrollPane.setBounds(0,10,690,496);
		
		// clear existing data from the model
		model.setRowCount(0);

        // populate the table with the updated data
        ArrayList<StaffWindowManagement> inBooking = new StaffWindowController().getCheckInTable();

       for (int i = 0; i < inBooking.size(); i++) {
    	   StaffWindowManagement ib = inBooking.get(i);
    	   String[] rowData = { ib.getFullName(), ib.getArrivalDate().toString(), ib.getDepartureDate().toString(),
    			   ib.getRoomType().toString(), String.valueOf(ib.getRoomNumber()), ib.getBookingStatus()};
		        model.addRow(rowData);
       }

       // notify the table that the data has changed
       model.fireTableDataChanged();
		
    	
		viewCheckInFrame.add(scrollPane);
		
    }
    
    private void initFrame5(JInternalFrame checkOutFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,cusIdLbl,bookingLbl,arrivalDateLbl, departureDateLbl,rTypeLbl,rNumLbl;
    	JTextField cusIdFld,bookingFld;
    	JDateChooser arrDate,depDate;
    	JComboBox <String>rTypeComboBox;
    	JComboBox <String>rNumComboBox;
    	JButton checkOutBtn,viewBtn,closeBtn;
    	Calendar arrCalendar,depCalendar;
    	DefaultTableModel inModel;
    	JTable inTable;
    	
    	checkOutFrame.setSize(700,500);
    	checkOutFrame.setLocation(400,200);
    	checkOutFrame.setResizable(false);
    	checkOutFrame.setLayout(null);
    	checkOutFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	checkOutFrame.setTitle("Checked-In Form");
	    
	    titleLbl = new JLabel("Today's Check-out Form");
	    titleLbl.setBounds(50,0,400,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(50, 50, 600, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    cusIdLbl = new JLabel("Customer ID");
	    cusIdLbl.setBounds(10,10,100,20);
	    cusIdLbl.setForeground(Color.black);
	    cusIdLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    cusIdFld = new JTextField();
	    cusIdFld.setBounds(120,10,150,25);
	    
	    bookingLbl = new JLabel("Booking Id");
	    bookingLbl.setBounds(320,10,150,20);
	    bookingLbl.setForeground(Color.black);
	    bookingLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    bookingFld = new JTextField();
	    bookingFld.setBounds(440,10,150,25);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,60,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,60,150,25);
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(320,60,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();
	    depDate.setBounds(440,60,150,25);
		
	    rTypeLbl = new JLabel("Room Type");
	    rTypeLbl.setBounds(10,110,100,20);
	    rTypeLbl.setForeground(Color.black);
	    rTypeLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	  
	    String rType[] = {"Single", "Double", "Twin"};
	    rTypeComboBox = new JComboBox <>(rType);
	    rTypeComboBox.setBounds(120, 110, 150, 25);
	    
	    
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(320,110,100,20);
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] rNum = {};
	    rNumComboBox = new JComboBox<>(rNum);
	    rNumComboBox.setSelectedIndex(-1);
	    rNumComboBox.setBounds(440, 110, 150, 25);
	    
		
	    checkOutBtn = new JButton("CHECK-OUT");
	    checkOutBtn.setBounds(70,180,140,30);
	    checkOutBtn.setFont(new Font("serif",Font.BOLD, 17));
	    checkOutBtn.setForeground(Color.black);
	    checkOutBtn.setBackground(Color.green);
		
	    checkOutBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==checkOutBtn) {
		    		if(ae.getSource()==checkOutBtn) {
			    		StaffWindowManagement swm = new StaffWindowManagement(Integer.parseInt(cusIdFld.getText()),Integer.parseInt(bookingFld.getText()),
			    		Integer.parseInt(rNumComboBox.getSelectedItem().toString()));
			    		
			    		boolean result = new StaffWindowController().confirmCheckOut(swm);
			    		if(result==true) {
			    		
			    			JOptionPane.showMessageDialog(checkOutFrame, "Checked-Out Successful");
			    			
			    			new StaffWindowController().confirmCheckIn(swm);
			    			cusIdFld.setText("");
			    			bookingFld.setText("");
			    			arrDate.setDate(null);
			    			depDate.setDate(null);
			    			rTypeComboBox.setSelectedIndex(-1);
			    			rNumComboBox.setSelectedIndex(-1);
			    			
			    			
		
			    		}else {
			    			JOptionPane.showMessageDialog(checkOutFrame, "Fail to Checked-Out");
			    			}
			    		
			    	}
		    	}
		    }
		});

		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(260,180,120,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		

		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the close button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		checkOutFrame.setVisible(false);
		    	}
		    }
		});
		
		viewBtn = new JButton("VIEW");
		viewBtn.setBounds(430,180,120,30);
		viewBtn.setFont(new Font("serif",Font.BOLD, 17));
		viewBtn.setForeground(Color.black);
		viewBtn.setBackground(Color.blue);
		
		
		
		viewBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		    	
		    	// notify the table that the data has changed
				outModel.fireTableDataChanged();
		    	desktopPane.add(viewCheckOutFrame, JLayeredPane.DEFAULT_LAYER);
		    	viewCheckOutFrame.setVisible(true);
		    	
		    }
		});
		
		
		String[] columnNames = {"Customer Id","Booking Id","Check-In Date","Check-Out Date","Room Type","Room No","Booking Status"};
		inModel = new DefaultTableModel(columnNames, 0);
		inTable = new JTable(inModel);
		inTable.setFont(new Font("serif",Font.BOLD, 12));
		
		
		JScrollPane scrollPane = new JScrollPane(inTable);
		scrollPane.setBounds(5, 235, 590, 164);
		
		// clear existing data from the model
		inModel.setRowCount(0);
				         
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> customers = new StaffWindowController().getCheckInTable();
				
		for (int i = 0; i < customers.size(); i++) {
			StaffWindowManagement customer = customers.get(i);
			String[] rowData = {Integer.toString(customer.getCustomerId()),Integer.toString(customer.getBookingId()),customer.getArrivalDate().toString(), 
			customer.getDepartureDate().toString(),customer.getRoomType().toString(),String.valueOf(customer.getRoomNumber()),customer.getBookingStatus()};
			inModel.addRow(rowData);
		}

		// notify the table that the data has changed
		inModel.fireTableDataChanged();
		new StaffWindowController().getCheckInTable();
		
		// Add a ListSelectionListener to the table
		inTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event) {
				if (!event.getValueIsAdjusting()) {
					// Get the selected row index
					int rowIndex = inTable.getSelectedRow();
					if (rowIndex >= 0) { // If a row is selected
						String customerId = (String) inTable.getValueAt(rowIndex,0);
						String bookingId = (String) inTable.getValueAt(rowIndex, 1);
						String arrivalDateStr = (String) inTable.getValueAt(rowIndex, 2);
						String departureDateStr = (String) inTable.getValueAt(rowIndex, 3);
						
						DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Replace the format string with your own date format
						
						Date arrivalDate = null;
						Date departureDate = null;
						
						try {
							arrivalDate = df.parse(arrivalDateStr);
							departureDate = df.parse(departureDateStr);
						} catch (ParseException e) {
							e.printStackTrace();
						}
						
						String roomType = (String) inTable.getValueAt(rowIndex, 4);
						String roomNum = (String) inTable.getValueAt(rowIndex, 5);
						
						
						// Set the values of the fields to the selected row values
						cusIdFld.setText(customerId);
						bookingFld.setText(bookingId);
						arrDate.setDate(arrivalDate);
						depDate.setDate(departureDate);		                 		                 
						rTypeComboBox.setSelectedItem(roomType);
			            rNumComboBox.removeAllItems(); // clear existing items 
			            rNumComboBox.addItem(roomNum); // add new items
			             	
						
					}   		               
				}
			}
		});
        
	    panel.add(cusIdLbl);
	    panel.add(cusIdFld);
	    panel.add(bookingLbl);
	    panel.add(bookingFld);
	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(rTypeLbl);
	    panel.add(rTypeComboBox);
	    panel.add(rNumLbl);
	    panel.add(rNumComboBox);
	    panel.add(checkOutBtn);
	    panel.add(closeBtn);
	    panel.add(viewBtn);
	    panel.add(scrollPane);
	    
	    
	    checkOutFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    checkOutFrame.getContentPane().add(panel);
	    
	}
    
    private void initFrame6(JInternalFrame viewCheckOutFrame) {
    	viewCheckOutFrame.setSize(700,500);
    	viewCheckOutFrame.setLocation(400,270);
    	viewCheckOutFrame.setResizable(false);
    	viewCheckOutFrame.setLayout(null);
    	viewCheckOutFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	viewCheckOutFrame.setTitle("Customer Checked-Out List");
    	
    	String[] columnNames = {"Full Name","Check-In Date","Check-Out Date","Room Type","Room No","Booking Status"};
    	outModel = new DefaultTableModel(columnNames, 0);
    	outTable = new JTable(outModel);
		outTable.setFont(new Font("serif",Font.BOLD, 12));
		
		
		JScrollPane scrollPane = new JScrollPane(outTable);
		scrollPane.setBounds(0,10,690,496);
		
		// clear existing data from the model
		outModel.setRowCount(0);
		         
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> customers = new StaffWindowController().getCheckOut();
		
		for (int i = 0; i < customers.size(); i++) {
			StaffWindowManagement customer = customers.get(i);
			String[] rowData = {Integer.toString(customer.getCustomerId()),Integer.toString(customer.getBookingId()),customer.getArrivalDate().toString(), 
			customer.getDepartureDate().toString(),customer.getRoomType().toString(),String.valueOf(customer.getRoomNumber()),customer.getBookingStatus()};
			outModel.addRow(rowData);
		}

		// notify the table that the data has changed
		outModel.fireTableDataChanged();
    	
		viewCheckOutFrame.add(scrollPane);

   	}
    	
    private void initFrame7(JInternalFrame addServiceFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,nameLbl,rNumLbl,serviceLbl,qtyLbl,rateLbl,priceLbl,totalLbl;
    	JTextField nameFld,qtyFld,rateFld,totalFld;
    	JComboBox <String> rNumComboBox;
    	JComboBox <String> serviceNameCombo;
    	JButton saveBtn,closeBtn;
    	DefaultTableModel serviceModel;
    	JTable exServiceTable;
    	
    	addServiceFrame.setSize(700,500);
    	addServiceFrame.setLocation(400,200);
    	addServiceFrame.setResizable(false);
    	addServiceFrame.setLayout(null);
    	addServiceFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	addServiceFrame.setTitle("Extra Services Form");
	    
	    titleLbl = new JLabel("Extra Services Form");
	    titleLbl.setBounds(18,0,300,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(20, 50, 650, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    nameLbl = new JLabel("Full Name");
	    nameLbl.setBounds(10,10,100,20);
	    nameLbl.setForeground(Color.black);
	    nameLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    nameFld = new JTextField();
	    nameFld.setBounds(120,10,150,25);
		
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(360,10,150,20);
	    rNumLbl.setHorizontalAlignment(SwingConstants.LEFT); // Set the alignment to left
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] rNum = {};
	    rNumComboBox = new JComboBox<>(rNum);
	    rNumComboBox.setBounds(480,10,150,25);
		
	    serviceLbl = new JLabel("Service Name");
	    serviceLbl.setBounds(10,60,100,20);
	    serviceLbl.setForeground(Color.black);
	    serviceLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] sName = {"Laundry","Spa"};
	    serviceNameCombo = new JComboBox<>(sName);
	    serviceNameCombo.setBounds(120, 60, 150, 25);
	    serviceNameCombo.setSelectedIndex(-1);
	    
	    qtyLbl = new JLabel("Quantity");
	    qtyLbl.setBounds(360,60,150,20);
	    qtyLbl.setForeground(Color.black);
	    qtyLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    qtyFld = new JTextField();
	    qtyFld.setBounds(480,60,150,25);
	    
	    rateLbl = new JLabel("Rate");
	    rateLbl.setBounds(10,110,100,20);
	    rateLbl.setForeground(Color.black);
	    rateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    priceLbl = new JLabel("£");
	    priceLbl.setBounds(100,100,40,40);
	    priceLbl.setFont(new Font("serif",Font.BOLD, 18));
	    
	    rateFld = new JTextField();
	    rateFld.setBounds(120, 110, 150, 25);
	    rateFld.setEditable(false);
	    
	    totalLbl = new JLabel("Total");
	    totalLbl.setBounds(360,110,150,20);
	    totalLbl.setForeground(Color.black);	// setting foreground color of text1 
	    totalLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
	    
		
	    totalFld = new JTextField();
		totalFld.setBounds(480,110,150,25);
		totalFld.setEditable(false);
		
		saveBtn = new JButton("SAVE");
		saveBtn.setBounds(160,170,120,30);
		saveBtn.setFont(new Font("serif",Font.BOLD, 17));
		saveBtn.setForeground(Color.black);
		saveBtn.setBackground(Color.green);
		
		String[] columnNames = {"Full Name","Room No.","Service Name","Quantity","Rate","Total"};
		serviceModel = new DefaultTableModel(columnNames, 0);
		exServiceTable = new JTable(serviceModel);
		exServiceTable.setFont(new Font("serif",Font.BOLD, 10));
		
		
		JScrollPane scrollPane = new JScrollPane(exServiceTable);
		scrollPane.setBounds(5, 220, 640, 180);
		
		ArrayList<StaffWindowManagement> roomNumbers = new StaffWindowController().getCheckedInRoomNumbers();
		rNumComboBox.removeAllItems(); // clear existing items
		for (int i = 0; i < roomNumbers.size(); i++) {
			StaffWindowManagement roomNumber = roomNumbers.get(i);
       	  	rNumComboBox.addItem(String.valueOf(roomNumber.getRoomNumber())); // add new items
       	  	rNumComboBox.setSelectedIndex(-1); 	
        }
		
		// Add an event listener to the room number combo box
		rNumComboBox.addActionListener(e -> {
		    // Get the selected room number from the combo box
		    String selectedRoomNumber = (String) rNumComboBox.getSelectedItem();
		    
		    // Call a function to fetch the corresponding customer name
		    ArrayList<String> customerNames = new StaffWindowJDBC().getCustomerName(selectedRoomNumber);

		    // If there is at least one customer name returned
		    if (!customerNames.isEmpty()) {
		        // Populate the customer text field with the first customer name
		        nameFld.setText(customerNames.get(0));
		    } else {
		        // Otherwise, set the customer text field to empty
		        nameFld.setText("");
		    }       
		});

		// add an action listener to the combo box
		serviceNameCombo.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // get the selected item in the combo box
		        String selectedItem = (String) serviceNameCombo.getSelectedItem();
		        // check if the selected item is not null before comparing
		        if (selectedItem != null) {
		            // update the text of rPriceFld based on the selected item
		            if (selectedItem.equals("Laundry")) {
		                rateFld.setText("2");
		            } else if (selectedItem.equals("Spa")) {
		                rateFld.setText("14");
		            }
		        }
		    }
		});

		saveBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		        if (ae.getSource() == saveBtn) {
		            // Get the selected room number from the combo box
		            String selectedRoomNumber = (String) rNumComboBox.getSelectedItem();
		            
		            // Create a new StaffWindowManagement object to store the data
		            StaffWindowManagement swm = new StaffWindowManagement();
		            swm.setRoomNumber(Integer.parseInt(selectedRoomNumber));
		            
		            // Get the selected service name and set the service ID accordingly
		            String selectedItem = (String) serviceNameCombo.getSelectedItem();
		            if (selectedItem.equals("Laundry")) {
		                swm.setExtServiceId(1);
		            } else if (selectedItem.equals("Spa")) {
		                swm.setExtServiceId(2);
		            }
		            
		            int quantity = Integer.parseInt(qtyFld.getText());
		            int rate = Integer.parseInt(rateFld.getText());
		            int total = quantity * rate;
		            totalFld.setText(Integer.toString(total));
		            swm.setQuantity(quantity);
		            swm.setTotal(total);
		            
		            // Add the extra service to the database
		            boolean result = new StaffWindowJDBC().addExtService(swm);
		            
		            // Check the result and display a message to the user
		            if (result) {
		                JOptionPane.showMessageDialog(null, "Extra service added successfully!");
		                updateServiceTable();
		                new StaffWindowController().getExtraServiceTable();
		                
		                nameFld.setText("");
		                rNumComboBox.setSelectedIndex(-1);
		                serviceNameCombo.setSelectedIndex(-1);
		                qtyFld.setText("");
		                rateFld.setText("");
		                totalFld.setText("");
		             
		            } else {
		                JOptionPane.showMessageDialog(null, "Error adding extra service.");
		            }
		        }
		    }
		    public void updateServiceTable() {
				
				serviceModel.setRowCount(0);
				// populate the table with the updated data
				ArrayList<StaffWindowManagement> services = new StaffWindowController().getExtraServiceTable();
				for (int i = 0; i < services.size(); i++) {
					StaffWindowManagement service = services.get(i);
					String[] rowData = {service.getFullName(),String.valueOf(service.getRoomNumber()),service.getServiceName(),String.valueOf(service.getQuantity()),
							String.valueOf(service.getRate()),String.valueOf(service.getTotal())};
					serviceModel.addRow(rowData);
				
				}
				// notify the table that the data has changed
				serviceModel.fireTableDataChanged();
			}
		});
		
		
		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(370,170,120,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		
		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		addServiceFrame.setVisible(false);
		    	}
		    }
		});
		
		serviceModel.setRowCount(0);
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> services = new StaffWindowController().getExtraServiceTable();
		for (int i = 0; i < services.size(); i++) {
			StaffWindowManagement service = services.get(i);
			String[] rowData = {service.getFullName(),String.valueOf(service.getRoomNumber()),service.getServiceName(),String.valueOf(service.getQuantity()),
					String.valueOf(service.getRate()),String.valueOf(service.getTotal())};
			serviceModel.addRow(rowData);
		
		}
		// notify the table that the data has changed
		serviceModel.fireTableDataChanged();
		
	    panel.add(nameLbl);
	    panel.add(nameFld);
	    panel.add(rNumLbl);
	    panel.add(rNumComboBox);
	    panel.add(serviceLbl);
	    panel.add(serviceNameCombo);
	    panel.add(qtyLbl);
	    panel.add(qtyFld);
	    panel.add(rateLbl);
	    panel.add(rateFld);
	    panel.add(priceLbl);
	    panel.add(totalLbl);
	    panel.add(totalFld);
	    panel.add(saveBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    
	    
	    addServiceFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    addServiceFrame.getContentPane().add(panel);
	
	}
    
private void initFrame8(JInternalFrame rbFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,nameLbl,rNumLbl,serviceLbl,qtyLbl,rateLbl,priceLbl,totalLbl;
    	JTextField nameFld,qtyFld,rateFld,totalFld;
    	JComboBox <String> rNumComboBox;
    	JComboBox <String> serviceNameCombo;
    	JButton saveBtn, closeBtn;
    	DefaultTableModel serviceModel;
    	JTable exServiceTable;
    	
    	rbFrame.setSize(700,500);
    	rbFrame.setLocation(400,200);
    	rbFrame.setResizable(false);
    	rbFrame.setLayout(null);
    	rbFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	rbFrame.setTitle("Restaurant and Bar");
	    
	    titleLbl = new JLabel("Restaurant and Bar");
	    titleLbl.setBounds(18,0,300,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(20, 50, 650, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    nameLbl = new JLabel("Full Name");
	    nameLbl.setBounds(10,10,100,20);
	    nameLbl.setForeground(Color.black);
	    nameLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    nameFld = new JTextField();
	    nameFld.setBounds(120,10,150,25);
		
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(360,10,150,20);
	    rNumLbl.setHorizontalAlignment(SwingConstants.LEFT); // Set the alignment to left
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] rNum = {};
	    rNumComboBox = new JComboBox<>(rNum);
	    rNumComboBox.setBounds(480,10,150,25);
		
	    serviceLbl = new JLabel("Item Name");
	    serviceLbl.setBounds(10,60,100,20);
	    serviceLbl.setForeground(Color.black);
	    serviceLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    String [] sName = {"Burger","Pizza","Chicken Wings","Beer","Wine"};
	    serviceNameCombo = new JComboBox<>(sName);
	    serviceNameCombo.setBounds(120, 60, 150, 25);
	    serviceNameCombo.setSelectedIndex(-1);
	    
	    qtyLbl = new JLabel("Quantity");
	    qtyLbl.setBounds(360,60,150,20);
	    qtyLbl.setForeground(Color.black);
	    qtyLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    qtyFld = new JTextField();
	    qtyFld.setBounds(480,60,150,25);
	    
	    rateLbl = new JLabel("Rate");
	    rateLbl.setBounds(10,110,100,20);
	    rateLbl.setForeground(Color.black);
	    rateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    priceLbl = new JLabel("£");
	    priceLbl.setBounds(100,100,40,40);
	    priceLbl.setFont(new Font("serif",Font.BOLD, 18));
	    
	    rateFld = new JTextField();
	    rateFld.setBounds(120, 110, 150, 25);
	    rateFld.setEditable(false);
	    
	    totalLbl = new JLabel("Total");
	    totalLbl.setBounds(360,110,150,20);
	    totalLbl.setForeground(Color.black);	// setting foreground color of text1 
	    totalLbl.setFont(new Font("serif",Font.BOLD, 15));	// setting font of text1
	    
		
	    totalFld = new JTextField();
		totalFld.setBounds(480,110,150,25);
		totalFld.setEditable(false);
		
		saveBtn = new JButton("SAVE");
		saveBtn.setBounds(160,170,120,30);
		saveBtn.setFont(new Font("serif",Font.BOLD, 17));
		saveBtn.setForeground(Color.black);
		saveBtn.setBackground(Color.green);
		
		String[] columnNames = {"Full Name","Room No.","Service Name","Quantity","Rate","Total"};
		serviceModel = new DefaultTableModel(columnNames, 0);
		exServiceTable = new JTable(serviceModel);
		exServiceTable.setFont(new Font("serif",Font.BOLD, 10));
		
		
		JScrollPane scrollPane = new JScrollPane(exServiceTable);
		scrollPane.setBounds(5, 220, 640, 180);
		
		serviceModel.setRowCount(0);
		
		ArrayList<StaffWindowManagement> roomNumbers = new StaffWindowController().getCheckedInRoomNumbers();
		rNumComboBox.removeAllItems(); // clear existing items
		for (int i = 0; i < roomNumbers.size(); i++) {
			StaffWindowManagement roomNumber = roomNumbers.get(i);
       	  	rNumComboBox.addItem(String.valueOf(roomNumber.getRoomNumber())); // add new items
       	  	rNumComboBox.setSelectedIndex(-1); 	
        }
		
		// Add an event listener to the room number combo box
        rNumComboBox.addActionListener(e -> {
        	// Get the selected room number from the combo box
            String selectedRoomNumber = (String) rNumComboBox.getSelectedItem();

            // Call a function to fetch the corresponding customer name
            ArrayList<String> customerNames = new StaffWindowJDBC().getCustomerName(selectedRoomNumber);

            // If there is at least one customer name returned
            if (!customerNames.isEmpty()) {
                // Populate the customer text field with the first customer name
                nameFld.setText(customerNames.get(0));
            } else {
                // Otherwise, set the customer text field to empty
                nameFld.setText("");
            }       
            
        });
		
		// add an action listener to the combo box
	    serviceNameCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                // get the selected item in the combo box
                String selectedItem = (String) serviceNameCombo.getSelectedItem();
                // check if the selected item is not null before comparing
                if (selectedItem != null) {
	                // update the text of rPriceFld based on the selected item
	                if (selectedItem.equals("Burger")) {
	                    rateFld.setText("3");
	                    
	                } else if (selectedItem.equals("Pizza")) {
	                    rateFld.setText("3");
	                    }
	                else if (selectedItem.equals("Wine")) {
	                    rateFld.setText("10");
	                    }
	                else if (selectedItem.equals("Chicken Wings")) {
	                    rateFld.setText("4");
	                    }
	                else if (selectedItem.equals("Beer")) {
	                    rateFld.setText("4");
	                    }
                }
            }
        });

		
		saveBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==saveBtn) {
		    		
		    		 // Get the selected room number from the combo box
		            String selectedRoomNumber = (String) rNumComboBox.getSelectedItem();
		            
		            // Create a new StaffWindowManagement object to store the data
		            StaffWindowManagement swm = new StaffWindowManagement();
		            swm.setRoomNumber(Integer.parseInt(selectedRoomNumber));
		            
		            // Get the selected service name and set the service ID accordingly
		            String selectedItem = (String) serviceNameCombo.getSelectedItem();
		            if (selectedItem.equals("Burger")) {
	                    swm.setRBServiceId(1);
	                    
	                } else if (selectedItem.equals("Pizza")) {
	                	swm.setRBServiceId(2);
	                    }
	                else if (selectedItem.equals("Wine")) {
	                	swm.setRBServiceId(5);
	                    }
	                else if (selectedItem.equals("Chicken Wings")) {
	                	swm.setRBServiceId(3);
	                    }
	                else if (selectedItem.equals("Beer")) {
	                	swm.setRBServiceId(4);
	                    }
		            
		            int quantity = Integer.parseInt(qtyFld.getText());
		            int rate = Integer.parseInt(rateFld.getText());
		            int total = quantity * rate;
		            totalFld.setText(Integer.toString(total));
		            swm.setQuantity(quantity);
		            swm.setTotal(total);
		            
		            // Add the extra service to the database
		            boolean result = new StaffWindowJDBC().addRBService(swm);
		            
		            // Check the result and display a message to the user
		            if (result) {
		                JOptionPane.showMessageDialog(null, "Item added successfully!");
		                updateServiceTable();
		                new StaffWindowController().getRBServiceTable();
		                
		                nameFld.setText("");
		                rNumComboBox.setSelectedIndex(-1);
		                serviceNameCombo.setSelectedIndex(-1);
		                qtyFld.setText("");
		                rateFld.setText("");
		                totalFld.setText("");
		             
		            } else {
		                JOptionPane.showMessageDialog(null, "Error adding Item.");
		            }
		        }
		    }
		    public void updateServiceTable() {
				
				serviceModel.setRowCount(0);
				// populate the table with the updated data
				ArrayList<StaffWindowManagement> services = new StaffWindowController().getRBServiceTable();
				for (int i = 0; i < services.size(); i++) {
					StaffWindowManagement service = services.get(i);
					String[] rowData = {service.getFullName(),String.valueOf(service.getRoomNumber()),service.getServiceName(),String.valueOf(service.getQuantity()),
							String.valueOf(service.getRate()),String.valueOf(service.getTotal())};
					serviceModel.addRow(rowData);
				
				}
				// notify the table that the data has changed
				serviceModel.fireTableDataChanged();
			}
		});


		
		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(370,170,120,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		
		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		rbFrame.setVisible(false);
		    	}
		    }
		});

		serviceModel.setRowCount(0);
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> services = new StaffWindowController().getRBServiceTable();
		for (int i = 0; i < services.size(); i++) {
			StaffWindowManagement service = services.get(i);
			String[] rowData = {service.getFullName(),String.valueOf(service.getRoomNumber()),service.getServiceName(),String.valueOf(service.getQuantity()),
					String.valueOf(service.getRate()),String.valueOf(service.getTotal())};
			serviceModel.addRow(rowData);
		
		}
		// notify the table that the data has changed
		serviceModel.fireTableDataChanged();
        
	    panel.add(nameLbl);
	    panel.add(nameFld);
	    panel.add(rNumLbl);
	    panel.add(rNumComboBox);
	    panel.add(serviceLbl);
	    panel.add(serviceNameCombo);
	    panel.add(qtyLbl);
	    panel.add(qtyFld);
	    panel.add(rateLbl);
	    panel.add(rateFld);
	    panel.add(priceLbl);
	    panel.add(totalLbl);
	    panel.add(totalFld);
	    panel.add(saveBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    
	    
	    rbFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    rbFrame.getContentPane().add(panel);
	
	}
    
    private void initFrame9(JInternalFrame createBillFrame) {
    	
    	JPanel panel;
    	JLabel titleLbl,nameLbl,rNumLbl,arrivalDateLbl,departureDateLbl;
    	JTextField nameFld,rNumFld;
    	JDateChooser arrDate,depDate;
    	JButton generateBtn,closeBtn;
    	DefaultTableModel billModel;
    	JTable billTable;
    	
    	createBillFrame.setSize(700,500);
    	createBillFrame.setLocation(400,200);
    	createBillFrame.setResizable(false);
    	createBillFrame.setLayout(null);
    	createBillFrame.getContentPane().setBackground(new Color(255, 255, 153, 150)); // Set background color with alpha value
    	createBillFrame.setTitle("Billing Form");
	    
	    titleLbl = new JLabel("Billing Form");
	    titleLbl.setBounds(30,0,200,50);
	    titleLbl.setFont(new Font("serif",Font.BOLD, 30));;
	    titleLbl.setForeground(Color.red);
	    
	 // Create a JPanel with a border line
	    panel = new JPanel();
	    panel.setBounds(20, 50, 650, 400);
	    panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Set the border line color and thickness
	    panel.setLayout(null);
	    
	    nameLbl = new JLabel("Full Name");
	    nameLbl.setBounds(10,10,100,20);
	    nameLbl.setForeground(Color.black);
	    nameLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    nameFld = new JTextField();
	    nameFld.setBounds(120,10,150,25);
	    
	    rNumLbl = new JLabel("Room No.");
	    rNumLbl.setBounds(320,10,150,20);
	    rNumLbl.setForeground(Color.black);
	    rNumLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    rNumFld = new JTextField();
	    rNumFld.setBounds(440,10,150,25);
	    
	    arrivalDateLbl = new JLabel("Check-In Date");
	    arrivalDateLbl.setBounds(10,60,100,20);
	    arrivalDateLbl.setForeground(Color.black);
	    arrivalDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    arrDate = new JDateChooser();
	    arrDate.setBounds(120,60,150,25);
		
	    departureDateLbl = new JLabel("Check-Out Date");
	    departureDateLbl.setBounds(320,60,150,20);
	    departureDateLbl.setForeground(Color.black);
	    departureDateLbl.setFont(new Font("serif",Font.BOLD, 15));
	    
	    depDate = new JDateChooser();
	    depDate.setBounds(440,60,150,25);
	    
	    
	    String[] columnNames = {"Full Name","Check-In Date","Check-Out Date","Room Type","Room No","Booking Status"};
		billModel = new DefaultTableModel(columnNames, 0);
		billTable = new JTable(billModel);
		billTable.setFont(new Font("serif",Font.BOLD, 10));
		
		
		JScrollPane scrollPane = new JScrollPane(billTable);
		scrollPane.setBounds(5, 170, 640, 230);
		
		// clear existing data from the model
		billModel.setRowCount(0);
		
		// populate the table with the updated data
		ArrayList<StaffWindowManagement> customers = new StaffWindowController().getCheckInTable();
						
		for (int i = 0; i < customers.size(); i++) {
			StaffWindowManagement customer = customers.get(i);
			String[] rowData = {customer.getFullName(),customer.getArrivalDate().toString(),customer.getDepartureDate().toString(),
					customer.getRoomType().toString(),String.valueOf(customer.getRoomNumber()),customer.getBookingStatus()};
					billModel.addRow(rowData);
		}

		// notify the table that the data has changed
		billModel.fireTableDataChanged();
		
		// Add a ListSelectionListener to the table
				billTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
				    public void valueChanged(ListSelectionEvent event) {
				        if (!event.getValueIsAdjusting()) {
				        	// Get the selected row index
				            int rowIndex = billTable.getSelectedRow();
				            if (rowIndex >= 0) { // If a row is selected
				            	
				            	String fName = (String) billTable.getValueAt(rowIndex, 0);
				            	String arrivalDateStr = (String) billTable.getValueAt(rowIndex, 1);
				            	String departureDateStr = (String) billTable.getValueAt(rowIndex, 2);

				            	DateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // Replace the format string with your own date format

				            	Date arrivalDate = null;
				            	Date departureDate = null;

				            	try {
				            	    arrivalDate = df.parse(arrivalDateStr);
				            	    departureDate = df.parse(departureDateStr);
				            	} catch (ParseException e) {
				            	    e.printStackTrace();
				            	}

				            	 String rNum = (String) billTable.getValueAt(rowIndex, 4);
				                 // Set the values of the fields to the selected row values
				            	 nameFld.setText(fName);
				            	 arrDate.setDate(arrivalDate);
				                 depDate.setDate(departureDate);
				                 rNumFld.setText(rNum);
				                 
				                 
				                 int roomNumber = Integer.parseInt(rNumFld.getText());
				                 StaffWindowManagement swm = new StaffWindowManagement();
				                 swm.setRoomNumber(roomNumber);
				                 
				            }	
				        }
				    }
				});
		
	    generateBtn = new JButton("GENERATE");
		generateBtn.setBounds(10,110,130,30);
		generateBtn.setFont(new Font("serif",Font.BOLD, 17));
		generateBtn.setForeground(Color.black);
		generateBtn.setBackground(Color.green);
		
		generateBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource() == generateBtn) {		    		
		    	    Date selectedCheckOutDate = depDate.getDate();
		    	    java.sql.Date sqlCheckOutDate = new java.sql.Date(selectedCheckOutDate.getTime());		    		
		    	    int roomNumber = Integer.parseInt(rNumFld.getText());		    		
		    	    StaffWindowManagement swm = new StaffWindowManagement(sqlCheckOutDate, roomNumber);
		    	    swm.setRoomNumber(roomNumber);
		    	    boolean result = new StaffWindowController().addBill(swm);		    		
		    	    if(result == true) {
		    	        BillFrame bf = new BillFrame();
		    	        bf.setVisible(true);
		    	        updateCheckIntable();
		    	        new StaffWindowController().getCheckInTable();			    					    		
		    	    }
		    	}

		    }
		    public void updateCheckIntable() {
				
				billModel.setRowCount(0);
				// populate the table with the updated data
				ArrayList<StaffWindowManagement> customers = new StaffWindowController().getCheckInTable();
				for (int i = 0; i < customers.size(); i++) {
					StaffWindowManagement customer = customers.get(i);
					String[] rowData = {customer.getFullName(),customer.getArrivalDate().toString(),customer.getDepartureDate().toString(),
							customer.getRoomType().toString(),String.valueOf(customer.getRoomNumber()),customer.getBookingStatus()};
					billModel.addRow(rowData);
				
				}
				// notify the table that the data has changed
				billModel.fireTableDataChanged();
			}
		});

		
		
		closeBtn = new JButton("CLOSE");
		closeBtn.setBounds(160,110,130,30);
		closeBtn.setFont(new Font("serif",Font.BOLD, 17));
		closeBtn.setForeground(Color.black);
		closeBtn.setBackground(Color.red);
		
		closeBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent ae) {
		        // This code will be executed when the submit button is clicked
		    	if(ae.getSource()==closeBtn) {
		    		createBillFrame.setVisible(false);
		    	}
		    }
		});

		
		
		
        panel.add(nameLbl);
        panel.add(nameFld);
        panel.add(rNumLbl);
        panel.add(rNumFld);
	    panel.add(arrivalDateLbl);
	    panel.add(arrDate);
	    panel.add(departureDateLbl);
	    panel.add(depDate);
	    panel.add(generateBtn);
	    panel.add(closeBtn);
	    panel.add(scrollPane);
	    
	    
	    createBillFrame.getContentPane().add(titleLbl);
	 // Add the panel to the content pane of the JInternalFrame
	    createBillFrame.getContentPane().add(panel);
	
	}
    
	
	@Override
    public void actionPerformed(ActionEvent ae) {
       
		if (ae.getSource() == view) {
			if (!desktopPane.isAncestorOf(viewFrame)) {
    			desktopPane.add(viewFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(viewFrame, JLayeredPane.DEFAULT_LAYER);
    		}
			viewFrame.setVisible(true);
    		
   		 
       }
		else if (ae.getSource() == checkIn) {
			if (!desktopPane.isAncestorOf(checkInFrame)) {
    			desktopPane.add(checkInFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(checkInFrame, JLayeredPane.DEFAULT_LAYER);
    		}
			checkInFrame.setVisible(true);	 
        }
    	else if(ae.getSource()==checkOut) {
    		if (!desktopPane.isAncestorOf(checkOutFrame)) {
    			desktopPane.add(checkOutFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(checkOutFrame, JLayeredPane.DEFAULT_LAYER);
    		}
    		checkOutFrame.setVisible(true);	
    	}
    	else if(ae.getSource()==add) {
    		if (!desktopPane.isAncestorOf(addServiceFrame)) {
    			desktopPane.add(addServiceFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(addServiceFrame, JLayeredPane.DEFAULT_LAYER);
    		}
    		addServiceFrame.setVisible(true);	
    	}
    	else if(ae.getSource()==create) {
    		if (!desktopPane.isAncestorOf(createBillFrame)) {
    			desktopPane.add(createBillFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(createBillFrame, JLayeredPane.DEFAULT_LAYER);
    		}
    		createBillFrame.setVisible(true);	
    	}
    	else if(ae.getSource()==addRB) {
    		if (!desktopPane.isAncestorOf(rbFrame)) {
    			desktopPane.add(rbFrame, JLayeredPane.DEFAULT_LAYER);
    		} else {
    			desktopPane.setLayer(rbFrame, JLayeredPane.DEFAULT_LAYER);
    		}
    		rbFrame.setVisible(true);	
    	}
    	else if(ae.getSource()==close) {
    		this.dispose();
    		MainWindow mw = new MainWindow();
    		mw.setVisible(true);
    		
    	}
    }
    
    public static void main(String[] args) {
        new StaffWindow();
    }
}
