package views;

import javax.swing.*;

import controllers.LoginController;
import models.CustomerLoginManagement;
import models.RegisterManagement;

import java.awt.*;
import java.awt.event.*;

public class GuestLoginWindow extends JFrame implements ActionListener{
	
	JLabel customerTypeLbl, userLbl, passLbl;
	JTextField userFld, passFld;
	JCheckBox passwordCheck;
	JButton loginBtn, signUpBtn, closeBtn;
	JComboBox <String> customerTypeComboBox;
	
	public GuestLoginWindow() {
		
		setTitle("Login Window");
		setSize(350,250);
		setResizable(false);
		setLocation(640,360);
		setUndecorated(true); // remove window decorations
	    getRootPane().setOpaque(false); // make the content pane transparent
	    setBackground(new Color(10, 10, 10, 100)); // make the background transparent
	    setLayout(null);
	    
	    
	    customerTypeLbl = new JLabel("Customer Type:");
	    customerTypeLbl.setBounds(50,10,100,20);
	    customerTypeLbl.setBackground(Color.white);
	    
	    String cusType[] = {"Corporate", "Non-Corporate"};
	    customerTypeComboBox = new JComboBox<>(cusType);
	    customerTypeComboBox.setBounds(180,10,100,20);
	    customerTypeComboBox.setSelectedIndex(-1);
	    customerTypeComboBox.setBackground(Color.WHITE);
	    
		userLbl = new JLabel("Username/Email:");
		userLbl.setBounds(50,40,100,20);
        userLbl.setBackground(Color.WHITE);
        
		userFld = new JTextField();
		userFld.setBounds(50,65,200,20);
		
		passLbl = new JLabel("Password:");
		passLbl.setBounds(50,95,100,20);
		passLbl.setBackground(Color.WHITE);
		
		passFld = new JPasswordField();
		passFld.setBounds(50,120,200,20);
		
		passwordCheck = new JCheckBox("Show Password");
		passwordCheck.setBounds(90,150,110,20);
		passwordCheck.setFont(new Font("serif",Font.BOLD, 12));
		passwordCheck.setBackground(Color.WHITE);
		passwordCheck.addItemListener(new ItemListener() {
		    public void itemStateChanged(ItemEvent e) {
		        if (e.getStateChange() == ItemEvent.SELECTED) {
		            ((JPasswordField) passFld).setEchoChar((char)0); // show password
		        } else {
		            ((JPasswordField) passFld).setEchoChar('\u2022'); // hide password with bullet character
		        }
		    }
		});
		
		loginBtn= new JButton("Login");
		loginBtn.setBounds(50,180,80,20);
		loginBtn.setFont(new Font("serif",Font.BOLD, 12));
		loginBtn.addActionListener(this);
		
		signUpBtn = new JButton("Sign Up");
		signUpBtn.setBounds(150,180,80,20);
		signUpBtn.setFont(new Font("serif",Font.BOLD, 12));
		signUpBtn.addActionListener(this);
		
		closeBtn = new JButton("Close");
		closeBtn.setBounds(100,210,80,20);
		closeBtn.setFont(new Font("serif",Font.BOLD, 12));
		closeBtn.addActionListener(this);
		
		
		
		add(customerTypeLbl);
		add(customerTypeComboBox);
		add(userLbl);
		add(userFld);
		add(passLbl);
		add(passFld);
		add(passwordCheck);
		add(loginBtn);
		add(signUpBtn);
		add(closeBtn);
		
		setOpacity(0.9f);
		setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent ae) {
	    if (ae.getSource() == loginBtn) {
	    	
	    	if(customerTypeComboBox.getSelectedItem()=="Non-Corporate") {
		    	CustomerLoginManagement login = new CustomerLoginManagement();
				LoginController lc = new LoginController();
				
				login.setEmail(userFld.getText());
				login.setPassword(passFld.getText());
				lc.setUser(login);
				lc.nonCorporateCustomerLogin();
				login = lc.getUser();
			
				
				if(CustomerLoginManagement.getCustomerId()>=1) {
				
				JOptionPane.showMessageDialog(this, "Login Successful");
				
				this.dispose();
		    	GuestWindow guestWindow = new GuestWindow(login);
		    	guestWindow.setVisible(true);
				}
				else {
					JOptionPane.showMessageDialog(this, "Invalid username or password");
				}
	    	}
	    	else {
	    		CustomerLoginManagement login = new CustomerLoginManagement();
				LoginController lc = new LoginController();
				
				login.setEmail(userFld.getText());
				login.setPassword(passFld.getText());
				lc.setUser(login);
				lc.corporateCustomerLogin();
				login = lc.getUser();
				
				
				if(CustomerLoginManagement.getCustomerId()>=1) {
				
				JOptionPane.showMessageDialog(this, "Login Successful");
				
				this.dispose();
		    	GuestWindow guestWindow = new GuestWindow(login);
		    	guestWindow.setVisible(true);
				this.setVisible(false);
				}
				else {
					JOptionPane.showMessageDialog(this, "Invalid username or password");
				}
	    	}
	    }
	
	    else if(ae.getSource()==closeBtn) {
	    	dispose();
	    	
	    }
	    
	    else if(ae.getSource()==signUpBtn) {
	    	this.dispose();
	    	RegisterWindow rWindow = new RegisterWindow();
	    	rWindow.setVisible(true);
	    
	    }
	}
	public static void main(String[] args) {
		new GuestLoginWindow();
	}
}	
