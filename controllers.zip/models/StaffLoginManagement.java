package models;

public class StaffLoginManagement {

	public static int staffId;
	String email;
	String password;
	boolean isUser;
	
	public StaffLoginManagement() {
		
	}
	
	public StaffLoginManagement(int staffId, String email, String password, boolean isUser) {
		super();
		this.staffId = staffId;
		this.email = email;
		this.password = password;
		this.isUser = isUser;
	}

	public int getStaffId() {
		return staffId;
	}

	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isUser() {
		return isUser;
	}

	public void setUser(boolean isUser) {
		this.isUser = isUser;
	}
	
}
