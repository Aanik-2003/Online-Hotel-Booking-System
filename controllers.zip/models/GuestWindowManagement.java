package models;

import java.util.Date;

public class GuestWindowManagement {
	
	
	Date arrivalDate;
	Date departureDate;
	Object roomType;
	public static int roomTypeId;
	int numGuest;
	int pricePerDay;
	int roomPrice;
	String creditCard;
	Date expiryDate;
	String cvv;
	String bookingStatus;
	String fullName;
	int bookingId;
	
	public GuestWindowManagement() {
		
	}
	
	public GuestWindowManagement(Date arrivalDate, Date departureDate, Object roomType, int numGuest, int pricePerDay, String creditCard,
			Date expiryDate, String cvv) {
		
		
		this.arrivalDate = arrivalDate;
		this.departureDate = departureDate;
		this.roomType = roomType;
		this.numGuest = numGuest;
		this.pricePerDay = pricePerDay;
		this.creditCard = creditCard;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
	}

	public GuestWindowManagement(int bookingId,Date arrivalDate, Date departureDate, int numGuest, int pricePerDay) {
		
		this.bookingId = bookingId;
		this.arrivalDate = arrivalDate;
		this.departureDate = departureDate;
		this.numGuest = numGuest;
		this.pricePerDay = pricePerDay;
		
	}
	public GuestWindowManagement(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(int roomPrice) {
		this.roomPrice = roomPrice;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Object getRoomType() {
		return roomType;
	}

	public void setRoomType(Object roomType) {
		this.roomType = roomType;
	}

	
	public static int getRoomTypeId() {
		return roomTypeId;
	}

	public static void setRoomTypeId(int roomTypeId) {
		GuestWindowManagement.roomTypeId = roomTypeId;
	}

	public int getNumGuest() {
		return numGuest;
	}

	public void setNumGuest(int numGuest) {
		this.numGuest = numGuest;
	}

	public int getPricePerDay() {
		return pricePerDay;
	}

	public void setPricePerDay(int pricePerDay) {
		this.pricePerDay = pricePerDay;
	}

	public String getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public String getCvv() {
		return cvv;
	}
	
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
}